package org.unibl.etf.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

import org.unibl.etf.model.Blog;
import org.unibl.etf.model.Korisnici;
import org.unibl.etf.model.Korisnik;
import org.unibl.etf.model.Messages;

import com.google.gson.Gson;

public class ServerThread2 extends Thread {

	private ObjectInputStream in;
	private ObjectOutputStream out;
	private Socket socket;
	private Gson gson = new Gson();
	
	public ServerThread2(Socket s) {
		try {
			this.socket = s;
			out = new ObjectOutputStream(s.getOutputStream());
			in = new ObjectInputStream(s.getInputStream());
			Korisnici.korisnici.add(new Korisnik(s.getRemoteSocketAddress().toString(), new Date()));
		} catch(IOException e) {
			e.printStackTrace();
		}
		start();
	}
	
	
	@Override
	public void run() {
		try {
			System.out.println("STARTED2!!!");
			String ulaz="";
			while(!Messages.KRAJ.equals(ulaz)) {
				ulaz = (String)in.readObject();
				if(Messages.BR_KOR.equals(ulaz)) {
					System.out.println("In br kor!!!");
					out.writeObject(Server.NUM_CONNS);
				} else if(Messages.PRIJAVLJENI.equals(ulaz)) {
					out.writeObject(Korisnici.korisnici);
				} else if(Messages.KRAJ.equals(ulaz)) {
					
				} else {
					//pogresna opcija
					out.writeObject("GRESKA");
					//out.flush();
				}
				
			}
			
			
			socket.close();
			in.close();
			out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		//while(!"")
		
		
		
	}
	
}
