package org.unibl.etf.client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Date;
import java.util.ArrayList;

import org.unibl.etf.model.Blog;
import org.unibl.etf.model.Korisnici;
import org.unibl.etf.model.Messages;
import org.unibl.etf.server.Server;

public class Klijent {

	public static void main(String[] args) {
		
		try {
			InetAddress address = InetAddress.getByName("localhost");
			Socket s = new Socket(address, Server.PORT);
			ObjectInputStream in = new ObjectInputStream(s.getInputStream());
			ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
			
			
			Blog b = new Blog("Naslov", "Autor", new java.util.Date(), "Tekst");
			
			out.writeObject(Messages.KREIRAJ_BLOG);
			out.writeObject(b);
			//out.flush();
			
			out.writeObject(Messages.PRETRAZI);
			out.writeObject("Tekst");
			ArrayList<Blog> bl = (ArrayList<Blog>) in.readObject();
			System.out.println("Blog = " + bl);
			
			out.writeObject(Messages.SVI_BLOGOVI);
			ArrayList<Blog> bl2 = (ArrayList<Blog>) in.readObject();
			System.out.println("Blog = " + bl2);
			
			out.writeObject("KRAJ");
			//out.flush();
			out.close();
			in.close();
			s.close();
			
			Socket s2 = new Socket(address, 9001);
			ObjectInputStream in2 = new ObjectInputStream(s2.getInputStream());
			ObjectOutputStream out2 = new ObjectOutputStream(s2.getOutputStream());
			
			out2.writeObject(Messages.BR_KOR);
			Integer rez = (Integer)in2.readObject();
			System.out.println("BR KOR =  " + rez);
			
			out2.writeObject(Messages.PRIJAVLJENI);
			ArrayList<Korisnici> rez2 = (ArrayList<Korisnici>)in2.readObject();
			System.out.println("PRIJAVLJENI =  " + rez2);
			out2.writeObject(Messages.KRAJ);
			out2.close();
			in2.close();
			s2.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		/*out = new ObjectOutputStream(s.getOutputStream());
		in = new ObjectInputStream(s.getInputStream());*/
		
	}
}
