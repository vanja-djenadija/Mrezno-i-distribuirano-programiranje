package org.unibl.etf.model;

import java.util.Date;
import java.io.Serializable;
import java.util.ArrayList;

public class Blog implements Serializable {

	private String naslov;
	private String autor;
	private Date vrijemeKreiranja;
	private String tekst;
	private ArrayList<String> komentari = new ArrayList<>();
	
	public ArrayList<String> getKomentari() {
		return komentari;
	}
	public void setKomentari(ArrayList<String> komentari) {
		this.komentari = komentari;
	}
	public String getNaslov() {
		return naslov;
	}
	public void setNaslov(String naslov) {
		this.naslov = naslov;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public Date getVrijemeKreiranja() {
		return vrijemeKreiranja;
	}
	public void setVrijemeKreiranja(Date vrijemeKreiranja) {
		this.vrijemeKreiranja = vrijemeKreiranja;
	}
	public String getTekst() {
		return tekst;
	}
	public void setTekst(String tekst) {
		this.tekst = tekst;
	}
	public Blog(String naslov, String autor, Date vrijemeKreiranja, String tekst) {
		super();
		this.naslov = naslov;
		this.autor = autor;
		this.vrijemeKreiranja = vrijemeKreiranja;
		this.tekst = tekst;
	}
	public Blog() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Blog [naslov=" + naslov + ", autor=" + autor + ", vrijemeKreiranja=" + vrijemeKreiranja + ", tekst="
				+ tekst + "]";
	}
	
	
	
}
