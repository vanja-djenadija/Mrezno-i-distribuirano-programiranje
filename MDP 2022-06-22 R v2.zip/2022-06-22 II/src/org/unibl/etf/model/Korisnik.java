package org.unibl.etf.model;

import java.io.Serializable;
import java.util.Date;

public class Korisnik implements Serializable {

	private String IP;
	private Date vrijemeUspostavljanja;
	public Korisnik(String iP, Date vrijemeUspostavljanja) {
		super();
		IP = iP;
		this.vrijemeUspostavljanja = vrijemeUspostavljanja;
	}
	public Korisnik() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getIP() {
		return IP;
	}
	public void setIP(String iP) {
		IP = iP;
	}
	public Date getVrijemeUspostavljanja() {
		return vrijemeUspostavljanja;
	}
	public void setVrijemeUspostavljanja(Date vrijemeUspostavljanja) {
		this.vrijemeUspostavljanja = vrijemeUspostavljanja;
	}
	@Override
	public String toString() {
		return "Korisnik [IP=" + IP + ", vrijemeUspostavljanja=" + vrijemeUspostavljanja + "]";
	}
	
	
	
}
