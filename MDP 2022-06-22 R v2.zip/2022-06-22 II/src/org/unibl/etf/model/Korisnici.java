package org.unibl.etf.model;

import java.util.ArrayList;

public class Korisnici {

	public static ArrayList<Korisnik> korisnici = new ArrayList<>();
	
}
