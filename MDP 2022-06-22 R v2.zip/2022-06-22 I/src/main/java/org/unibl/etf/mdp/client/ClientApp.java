package org.unibl.etf.mdp.client;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.inject.Produces;
import javax.persistence.Entity;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.unibl.etf.mdp.model.Product;

public class ClientApp {

	private static String URI="http://localhost:8080/22-6-2022-PRVIFULL/api/proizvodi/";
	
	public static void main(String[] args) {
		try {
			System.out.println("URI = " + URI);
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(URI);
			Response response = target.request(MediaType.APPLICATION_JSON).get();
			List<Product> products = response.readEntity(new GenericType<List<Product>>() {});
			for(Product p : products) {
				System.out.println(p);
			}	
			target = client.target(URI);
			ArrayList<String> sifre = new ArrayList<>();
			sifre.add("s1");	sifre.add("s2");	sifre.add("s3");
			Product p1 = new Product(sifre, "Pr1", "Op1", "Tip1");
			response = target.request().post(javax.ws.rs.client.Entity.json(p1));
			System.out.println(response.getStatus());
			java.net.URI baseUri = UriBuilder.fromUri(URI).path("s4").build();
			String str = URI+"s4";
			target = client.target(str);
			response = target.request(MediaType.APPLICATION_JSON).delete();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
