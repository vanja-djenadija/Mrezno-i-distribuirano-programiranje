package org.unibl.etf.mdp.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

public class ProductService {

	public static ArrayList<Product> proizvodi = new ArrayList<>();
	//Promijeniti PATH zbog REST-a
	public static final String PATH = "."+File.separator+"Kryo"+File.separator;
	
	
	public static ArrayList<Product> pregledajProizvode() throws Exception {
		ArrayList<Product> rezultat = new ArrayList<>();
		File file = new File(PATH);
		File[] sviFajlovi = file.listFiles();
		Kryo kryo = new Kryo();
		kryo.register(Product.class);
		//System.out.println("IN!!!");
		PrintWriter pw = new PrintWriter(new File("./a.txt"));
		pw.println("a");
		pw.close();
		for(File f : sviFajlovi) {
			//System.out.println("U FAJLU!!!");
			Input in = new Input(new ObjectInputStream(new FileInputStream(f)));		
			Product pr = (Product)kryo.readClassAndObject(in);
			rezultat.add(pr);
			in.close();
		}
		return rezultat;
	}
	
	public static Product pregledajProizvod(String sifra) throws Exception {
		System.out.println("IN PR PR");
		System.out.println("SIFRA " + sifra);
		proizvodi = pregledajProizvode();
		for(int i=0; i<proizvodi.size(); i++) {
			for(int j=0; j<proizvodi.get(i).getSifre().size(); j++) {
				System.out.println(proizvodi.get(i).getSifre().get(j));
				if(proizvodi.get(i).getSifre().get(j).equals(sifra)) {
					System.out.println("ret product");
					return proizvodi.get(i);
				}
			}
		}
		return null;
	}
	
	public static boolean kreirajProizvod(Product p) throws Exception {
		proizvodi = pregledajProizvode();
		for(int i=0; i<proizvodi.size(); i++) {
			for(int j=0; j<p.getSifre().size(); j++) {
				if(proizvodi.get(i).getSifre().contains(p.getSifre().get(j))) {
					return false;
				}
			}
		}
		String fileName="pr_";
		for(String sifra : p.getSifre()) {
			fileName+=sifra;
		}
		Kryo kryo = new Kryo();
		kryo.register(Product.class);
		Output o = new Output(new ObjectOutputStream(new FileOutputStream(new File(PATH+fileName))));
		kryo.writeClassAndObject(o, p);
		o.close();
		System.out.println("true");
		return true;
	}
	
	public static boolean obrisiProizvod(String sifra) throws Exception {
		proizvodi = pregledajProizvode();
		for(int i=0; i<proizvodi.size(); i++) {
			//for(int j=0; j<p.getSifre().size(); j++) {
				if(proizvodi.get(i).getSifre().contains(sifra)) {
					String fileName="pr_";
					Product p = pregledajProizvod(sifra);
					for(String s : p.getSifre()) {
						fileName += s;
					}
					File f = new File(PATH+fileName);
					f.delete();
					return true;
				}
			//}
		}
		return false;
	}
	
	public static void main(String[] args) throws Exception {
		/*ArrayList<Product> pregledajProizvode = pregledajProizvode();
		for(Product p : pregledajProizvode) {
			System.out.println(p);
		}*/
		/*ArrayList<String> sifre = new ArrayList<>();
		sifre.add("s1");	sifre.add("s5");	sifre.add("s6");
		Product p1 = new Product(sifre, "Pr2", "Op2", "Tip2");
		kreirajProizvod(p1);*/
		/*boolean p = obrisiProizvod("s1");
		System.out.println(p);*/
		//System.out.println(p);
		//Test radi
		/*Kryo kryo = new Kryo();
		kryo.register(Product.class);
		Product p = new Product();
		p.setOpis("OPIs");
		Output o = new Output(new ObjectOutputStream(new FileOutputStream(new File("test.txt"))));
		kryo.writeClassAndObject(o, p);
		o.close();
		
		Input in = new Input(new ObjectInputStream(new FileInputStream(new File("test.txt"))));		
		Product pr = (Product)kryo.readClassAndObject(in);
		System.out.println(pr);*/
	}
	
}
