package org.unibl.etf.mdp.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.unibl.etf.mdp.model.User;

import com.google.gson.Gson;

public class Monitor {

	public static final String FILE = "users.json";
	public static ArrayList<Integer> instances = new ArrayList<>();

	static {
		Gson gson = new Gson();
		User user1 = new User("admin", "admin");
		User user2 = new User("root", "root");
		try (PrintWriter pw = new PrintWriter(new File(FILE))) {
			pw.println("[ " + gson.toJson(user1) + ",");
			pw.println(gson.toJson(user2) + " ]");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String username = "";
		String password = "";
		System.out.print("Unesite korisni�ko ime: ");
		username = scan.nextLine();
		System.out.print("Unesite lozinku: ");
		password = scan.nextLine();
		User user = new User(username, password);

		StringBuilder sb = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(new File(FILE)))) {
			String input = "";
			while ((input = br.readLine()) != null)
				sb.append(input);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Gson gson = new Gson();
		if (sb.toString().contains(gson.toJson(user))) {
			System.out.println("Uspje�no ulogovani.");
			new MonitorServer().start();

			while (true) {
				if (instances.size() > 0)
					System.out.println("Pokrenute isntance " + instances);
				System.out.print("Unesite isntancu za dodatne infomacije: ");
				int input = scan.nextInt();
				// TODO: ispis
			}
		} else {
			System.out.println("Nemate ovla��enje.");
		}
	}

}
