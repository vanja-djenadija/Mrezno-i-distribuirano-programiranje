package org.unibl.etf.mdp.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class MonitorThread extends Thread {

	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;

	public MonitorThread(Socket socket) {
		this.socket = socket;
		try {
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		start();
	}

	public void run() {
		try {
			while (true) {
				int input = Integer.parseInt(in.readLine());
				Monitor.instances.add(input);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}