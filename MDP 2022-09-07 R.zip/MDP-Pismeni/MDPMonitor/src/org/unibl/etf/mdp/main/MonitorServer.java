package org.unibl.etf.mdp.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class MonitorServer extends Thread {

	public static final int PORT = 10000;
	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;

	// SERVER za MDPsERVERiNFO
	public void run() {
		try (ServerSocket ss = new ServerSocket(PORT)) {
			while (true) {
				Socket socket = ss.accept();
				new MonitorThread(socket);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
