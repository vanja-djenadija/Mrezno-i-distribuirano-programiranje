package org.unibl.etf.mdp.main;

import java.util.ArrayList;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.Response.StatusType;

import org.unibl.etf.mdp.model.Narudzba;
import org.unibl.etf.mdp.model.Stavka;

public class Main {

	public static final String BASE_URL = "http://localhost:8080/Zadatak1/api/stavke/";
	private static Client client = ClientBuilder.newClient();

	public static void main(String[] args) {
		WebTarget baseTarget = client.target(BASE_URL);
		try (Response response = baseTarget.request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(new Stavka(125, "COCA COLA", 2, 50, false), MediaType.APPLICATION_JSON))) {
			String result = response.readEntity(Stavka.class).toString();
			System.out.println("POST: " + result);
		}
		try (Response response = baseTarget.request(MediaType.APPLICATION_JSON).get()) {
			String result = response.readEntity(ArrayList.class).toString();
			System.out.println("MENI: " + result);
		}
		WebTarget target = client.target(BASE_URL).path("1");
		try (Response response = target.request(MediaType.APPLICATION_JSON)
				.put(Entity.entity(new Stavka(), MediaType.APPLICATION_JSON))) {
			String result = response.readEntity(Stavka.class).toString();
			System.out.println("PUT: " + result);
		}
		try (Response response = baseTarget.request(MediaType.APPLICATION_JSON).get()) {
			String result = response.readEntity(ArrayList.class).toString();
			System.out.println("MENI: " + result);
		}
		try (Response response = target.request(MediaType.APPLICATION_JSON).delete()) {
			System.out.println("DELETE: " + response.getStatusInfo());
		}
		try (Response response = baseTarget.request(MediaType.APPLICATION_JSON).get()) {
			String result = response.readEntity(ArrayList.class).toString();
			System.out.println("MENI: " + result);
		}

		ArrayList<Stavka> stavke = new ArrayList<Stavka>();
		stavke.add(new Stavka(125, "COCA COLA", 2, 5, false));
		System.out.println("KLIJENT ZELI NARUCITI: " + stavke);

		WebTarget nTarget = client.target(BASE_URL).path("narudzbe");
		try (Response response = nTarget.request(MediaType.APPLICATION_JSON)
				.post(Entity.entity(stavke, MediaType.APPLICATION_JSON))) {
			StatusType type = response.getStatusInfo();
			if (type.equals(Status.CREATED)) {
				String result = response.readEntity(ArrayList.class).toString();
				System.out.println("POST NARUDZBA: " + result);
			}
			System.out.println("POST NARUDZBA status: " + type);
		}

		try (Response response = baseTarget.request(MediaType.APPLICATION_JSON).get()) {
			String result = response.readEntity(ArrayList.class).toString();
			System.out.println("MENI: " + result);
		}

		try (Response response = nTarget.request(MediaType.APPLICATION_JSON).get()) {
			ArrayList<Narudzba> narudzbe = response.readEntity(ArrayList.class);
			System.out.println("NARUDZBE: " + narudzbe.toString());
		}
	}

}
