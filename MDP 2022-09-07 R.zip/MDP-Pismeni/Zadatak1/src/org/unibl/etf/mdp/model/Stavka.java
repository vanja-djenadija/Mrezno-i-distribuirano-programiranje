package org.unibl.etf.mdp.model;

import java.io.Serializable;
import java.util.Random;

// prvo pi�e, pa hrana
// kolicina i cijena ne smiju biti manje od 0
public class Stavka implements Serializable{

	static int count;
	private int id;
	private String naziv;
	private int cijena;
	private int kolicina;
	private boolean hrana;
	private Random rand = new Random();

	public Stavka() {
		super();
		this.id = (++count);
		this.naziv = "NAZIV " + count;
		this.cijena = rand.nextInt(100) + 1;
		this.kolicina = rand.nextInt(100) + 1;
		setHrana(rand.nextInt(2) == 1);
	}

	public Stavka(int id, String naziv, int cijena, int kolicina, boolean hrana) {
		super();
		this.id = id;
		this.naziv = naziv;
		this.cijena = cijena;
		this.kolicina = kolicina;
		this.hrana = hrana;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public int getCijena() {
		return cijena;
	}

	public void setCijena(int cijena) {
		this.cijena = cijena;
	}

	public int getKolicina() {
		return kolicina;
	}

	public void setKolicina(int kolicina) {
		this.kolicina = kolicina;
	}

	public boolean isHrana() {
		return hrana;
	}

	public void setHrana(boolean hrana) {
		this.hrana = hrana;
	}

	@Override
	public String toString() {
		return "Stavka [id=" + id + ", naziv=" + naziv + ", cijena=" + cijena + ", kolicina=" + kolicina + ", hrana="
				+ hrana + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stavka other = (Stavka) obj;
		if (id != other.id)
			return false;
		return true;
	}

}
