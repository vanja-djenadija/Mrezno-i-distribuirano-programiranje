package org.unibl.etf.mdp.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Narudzba implements Serializable {

	private ArrayList<Stavka> naruceno;

	public Narudzba() {

	}

	public Narudzba(ArrayList<Stavka> naruceno) {
		this.naruceno = naruceno;
	}

	@Override
	public String toString() {
		return "Narudzba [naruceno=" + naruceno.toString() + "]";
	}
}
