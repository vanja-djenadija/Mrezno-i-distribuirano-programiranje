package org.unibl.etf.mdp.rest;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.unibl.etf.mdp.model.Narudzba;
import org.unibl.etf.mdp.model.Stavka;

@Path("/stavke")
public class RESTService {

	private static ArrayList<Stavka> meni = new ArrayList<>();
	private static ArrayList<Narudzba> narudzbe = new ArrayList<>();

	static {
		for (int i = 0; i < 10; i++)
			meni.add(new Stavka());
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getMeni() {
		return Response.ok().entity(meni).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/narudzbe")
	public Response getNarudzbe() {
		return Response.ok().entity(narudzbe).build();
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response addStavka(Stavka stavka) {
		boolean found = false;
		Stavka foundStavka = null;
		for (Stavka s : meni) {
			if (s.getId() == stavka.getId()) {
				found = true;
				foundStavka = s;
				break;
			}
		}
		if (stavka.getCijena() < 0 || stavka.getKolicina() < 0 || found)
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity(stavka).build();
		else {
			meni.add(stavka);
			return Response.status(Status.CREATED).entity(stavka).build();
		}
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/narudzbe")
	public Response addNarudzba(ArrayList<Stavka> stavke) {
		for (Stavka stavka : stavke) {
			if (!meni.contains(stavka)) {
				return Response.status(Status.NOT_FOUND).entity(new ArrayList<Stavka>()).build();
			}
		}
		for (Stavka stavka : stavke) {
			for (Stavka m : meni) {
				if (stavka.getId() == m.getId()) {
					int kolicina = stavka.getKolicina();
					int dostupno = m.getKolicina();
					if (kolicina > dostupno) {
						return Response.status(Status.NO_CONTENT).entity(new ArrayList<Stavka>()).build();
					} else {
						int novaKolicina = dostupno - kolicina;
						m.setKolicina(novaKolicina);
					}
				}
			}
		}
		narudzbe.add(new Narudzba(stavke));
		return Response.status(Status.CREATED).entity(stavke).build();
	}

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("{id}")
	public Response editStavka(@PathParam("id") int id, Stavka stavka) {
		boolean found = false;
		Stavka foundStavka = null;
		for (Stavka s : meni) {
			if (s.getId() == id) {
				found = true;
				foundStavka = s;
				break;
			}
		}
		if (stavka.getCijena() < 0 || stavka.getKolicina() < 0 || !found)
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity(stavka).build();
		else {
			meni.remove(foundStavka);
			stavka.setId(id);
			meni.add(stavka);
			return Response.status(Status.OK).entity(stavka).build();
		}
	}

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{id}")
	public Response deleteStavka(@PathParam("id") int id) {
		boolean found = false;
		Stavka foundStavka = null;
		for (Stavka s : meni) {
			if (s.getId() == id) {
				found = true;
				foundStavka = s;
				break;
			}
		}
		if (!found)
			return Response.status(Status.BAD_REQUEST).build();
		else {
			meni.remove(foundStavka);
			return Response.status(Status.CREATED).build();
		}
	}

}
