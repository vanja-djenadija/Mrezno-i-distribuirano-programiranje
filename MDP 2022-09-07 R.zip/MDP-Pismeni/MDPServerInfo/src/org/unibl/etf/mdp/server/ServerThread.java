package org.unibl.etf.mdp.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class ServerThread extends Thread {

	private int id;
	private Socket socketMonitor;
	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;
	private PrintWriter outMonitor;

	public ServerThread(Socket socket, int id) {
		this.id = id;
		this.socket = socket;

		try {
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
			InetAddress address = InetAddress.getByName(Server.host);
			Socket socketMonitor = new Socket(address, 10000);
			outMonitor = new PrintWriter(new OutputStreamWriter(socketMonitor.getOutputStream()), true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		outMonitor.println("" + id);
		start();
	}

	public void run() {
		try {
			while (true) {
				String input = in.readLine();
				if ("GET_DATE".equals(input)) {
					DateFormat formatter1 = new SimpleDateFormat("dd.MM.yyyy");
					out.println(formatter1.format(new Date()));
					Server.users.add(id + "#" + new Date().toString() + "#" + input + "#");
				} else if ("GET_TIME".equals(input)) {
					DateFormat formatter1 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
					out.println(formatter1.format(new Date()));
					Server.users.add(id + "#" + new Date().toString() + "#" + input + "#");
				} else if (input.startsWith("GET_RANDOM")) {
					int a = Integer.parseInt(input.split("#")[1]);
					int b = Integer.parseInt(input.split("#")[2]);
					int c = new Random().nextInt(b - a) + a;
					out.println(c);
					Server.users.add(id + "#" + new Date().toString() + "#" + input + "#");
				} else
					out.println("Nepoznat unos");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
