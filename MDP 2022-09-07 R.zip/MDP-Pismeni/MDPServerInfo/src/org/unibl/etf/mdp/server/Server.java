package org.unibl.etf.mdp.server;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Properties;

public class Server {

	public static ArrayList<String> users = new ArrayList<>();
	public static final String CONFIG = "." + File.separator + "config.properties";
	private static int port;
	public static String host;
	private static int count;

	public static void main(String[] args) {
		try (ServerSocket ss = new ServerSocket(port + count)) {
			while (true) {
				Socket socket = ss.accept();
				new ServerThread(socket, count++);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void loadProperties() {
		Properties prop = new Properties();
		try {
			prop.load(new FileReader(new File(CONFIG)));
			port = Integer.parseInt(prop.getProperty("PORT"));
			host = prop.getProperty("HOST");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
