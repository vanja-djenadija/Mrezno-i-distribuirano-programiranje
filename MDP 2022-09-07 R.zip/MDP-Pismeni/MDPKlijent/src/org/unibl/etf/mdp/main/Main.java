package org.unibl.etf.mdp.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Properties;
import java.util.Scanner;

public class Main {

	public static final String CONFIG = "." + File.separator + "config.properties";
	private static int port;
	private static String host;
	private static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		loadProperties();
		try {
			InetAddress address = InetAddress.getByName(host);
			Socket socket = new Socket(address, port);
			PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			out.println("GET_DATE");
			System.out.println("GET_DATE Res: " + in.readLine());
			out.println("GET_TIME");
			System.out.println("GET_TIME Res: " + in.readLine());
			System.out.print("Unesite a: ");
			int a = scan.nextInt();
			System.out.print("Unesite b: ");
			int b = scan.nextInt();
			out.println("GET_RANDOM#" + a + "#" + b);
			System.out.println("GET_RANDOM Res: " + in.readLine());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void loadProperties() {
		Properties prop = new Properties();
		try {
			prop.load(new FileReader(new File(CONFIG)));
			port = Integer.parseInt(prop.getProperty("PORT"));
			host = prop.getProperty("HOST");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
