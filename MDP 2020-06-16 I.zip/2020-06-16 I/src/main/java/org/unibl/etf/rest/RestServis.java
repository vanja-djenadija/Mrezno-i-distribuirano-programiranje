package org.unibl.etf.rest;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.model.Vozilo;
import org.unibl.etf.model.VoziloServis;

@Path("/vozilo")
public class RestServis {

	@GET
	@Path("/{key}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dobijSve(@PathParam("key")int key) {
		ArrayList<Vozilo> pregledajSve = VoziloServis.pregledajSve(key);
		if(pregledajSve != null) {
			return Response.status(200).entity(pregledajSve).build();
		} else {
			return Response.status(403).build();
		}
	}
	
	@GET
	@Path("/{key}/{pr}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response pregledajPoProizvodjacu(@PathParam("key")int key, @PathParam("pr")String proizvodjac) {
		ArrayList<Vozilo> pregledajSve = VoziloServis.pregledajPoProizvodjacu(proizvodjac, key);
		if(pregledajSve != null) {
			return Response.status(200).entity(pregledajSve).build();
		} else {
			return Response.status(403).build();
		}
	}
	
	@DELETE
	@Path("/{key}/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response obrisi(@PathParam("key")int key, @PathParam("id") int id) {
		boolean rez = VoziloServis.obrisiVozilo(id, key);
		if(rez == true) {
			return Response.status(200).build();
		} else {
			return Response.status(403).build();
		}
	}
	
}
