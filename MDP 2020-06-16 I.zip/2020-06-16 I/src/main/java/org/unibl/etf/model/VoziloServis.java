package org.unibl.etf.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import com.google.gson.Gson;

public class VoziloServis {

	private static ArrayList<Vozilo> vozila = new ArrayList<>();
	
	public static final String PUTANJA = "."+File.separator+"Vozila"+File.separator;
	
	private static String iscitajKljuc(int key) {
		try {
			BufferedReader bf = new BufferedReader(new FileReader(new File("./api.txt")));
			String read = "";
			while((read=bf.readLine()) != null) {
				String[] parse = read.split("-");
				if(Integer.valueOf(parse[0]) == key) {
					bf.close();
					return parse[1];
				}
			}
			bf.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static ArrayList<Vozilo> pregledajSve(int kljuc) {
		ArrayList<Vozilo> rez = new ArrayList<>();
		Gson gson = new Gson();
		try {
			String str = iscitajKljuc(kljuc);
			if("GET".equals(str)) {
				File f = new File(PUTANJA);
				File[] fajlovi = f.listFiles();
				for(File fajl : fajlovi) {
					BufferedReader in = new BufferedReader(new FileReader(fajl));
					String tekst="", linija="";
					while((linija=in.readLine()) != null) {
						tekst += linija;
					}
					Vozilo v = gson.fromJson(tekst, Vozilo.class);
					rez.add(v);
					in.close();
					
				}
				return rez;
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static ArrayList<Vozilo> pregledajPoProizvodjacu(String proizvodjac, int kljuc) {
		ArrayList<Vozilo> rez = new ArrayList<>();
		try {
			String str = iscitajKljuc(kljuc);
			if("GETPR".equals(str)) {
				ArrayList<Vozilo> svaVozila = pregledajSve(1);
				for(int i=0; i<svaVozila.size(); i++) {
					if(proizvodjac != null && proizvodjac.equals(svaVozila.get(i).getProizvodjac())) {
						rez.add(svaVozila.get(i));
					}
				}
				return rez;
			}		
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static Vozilo pregledajPoId(int id, int kljuc) {
		try {
			String str = iscitajKljuc(kljuc);
			if("GETID".equals(str)) {
				ArrayList<Vozilo> svaVozila = pregledajSve(1);
				for(Vozilo v : svaVozila) {
					if(v.getId() == id) {
						return v;
					}
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static boolean obrisiVozilo(int id, int kljuc) {
		try {
			Gson gson = new Gson();
			ArrayList<Vozilo> vozila = pregledajSve(1);
			String str = iscitajKljuc(kljuc);
			if("DELETEID".equals(str)) {
				boolean pronasao=false;
				for(Vozilo v : vozila) {
					if(v.getId() == id) {
						pronasao = true;
					}
				}
				if(pronasao) {
					Vozilo v = new Vozilo(id);
					vozila.remove(v);
					File f = new File(PUTANJA);
					File[] fajlovi = f.listFiles();
					for(File fajl : fajlovi) {
						fajl.delete();
					}
					for(Vozilo vozilo : vozila) {
						File fi = new File(PUTANJA+"_"+vozilo.getId()+".json");
						PrintWriter pw = new PrintWriter(fi);
						pw.println(gson.toJson(vozilo));
						pw.close();
					}
					return true;
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static void populacija() throws FileNotFoundException {
		Gson gson = new Gson();
		for(int i=1; i<=10; i++) {
			Vozilo v = new Vozilo(i, 1998+i, "Pr"+i, "Model"+i, "Opis"+i);
			PrintWriter pw = new PrintWriter(new File(PUTANJA+"_"+v.getId()+".json"));
			pw.println(gson.toJson(v));
			pw.close();
		}
	}
	
	public static void main(String[] args) {
		try {
			//populacija();
			/*ArrayList<Vozilo> prSve = pregledajPoId(1, 2);
			for(Vozilo v : prSve) System.out.println(v);*/
			//Vozilo v = pregledajPoId(1, 2); System.out.println(v);
			/*boolean status = obrisiVozilo(1, 3);
			System.out.println(status);*/
			//System.out.println(iscitajKljuc(3));
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
