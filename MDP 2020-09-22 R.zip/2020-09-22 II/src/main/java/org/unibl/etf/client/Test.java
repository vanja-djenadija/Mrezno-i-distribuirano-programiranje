package org.unibl.etf.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class Test {

	public static final String URI = "http://numbersapi.com/random/year";
	public static final String URI2 = "http://numbersapi.com/";
	
	public static void main(String[] args) {
		
		try {
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(URI);
			Response response = target.request(MediaType.TEXT_PLAIN).get();
			String r = response.readEntity(String.class);
			System.out.println("Response1 = " + r);
			
			target = client.target(URI2+1978);
			response = target.request(MediaType.TEXT_PLAIN).get();
			String r2 = response.readEntity(String.class);
			System.out.println("Response2 = " + r2);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
