package org.unibl.etf.server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.model.Osoba;

import com.google.gson.Gson;

public class ServerThread extends Thread {

	ObjectOutputStream out;
	ObjectInputStream in;
	Socket socket;
	private static String URI="http://localhost:8080/22-9-2020-drugi/api/osoba/";
	
	public ServerThread(Socket s) {
		try {
			socket = s;
			out = new ObjectOutputStream(s.getOutputStream());
			in = new ObjectInputStream(s.getInputStream());
			start();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		try {
			
			String request = "";
			while(!"END".equals(request)) {
				request = (String)in.readObject();
				if("ADD".equals(request)) {
					Osoba o = (Osoba)in.readObject();
					Client client = ClientBuilder.newClient();
					WebTarget target = client.target(URI);
					Response response = target.request(MediaType.APPLICATION_JSON).put(Entity.entity(o, MediaType.APPLICATION_JSON));
					if(response.getStatus() == 201) {
						out.writeObject("OK");
					} else {
						out.writeObject("NOT_OK");
					}
					//System.out.println(o);
					//out.writeObject("OK");
				} else if("SHOW".equals(request)) {
					String jmb = (String)in.readObject();
					Client client = ClientBuilder.newClient();
					WebTarget target = client.target(URI+jmb);
					Response response = target.request(MediaType.APPLICATION_JSON).get();
					if(response.getStatus()==200) {
						Gson gson = new Gson();
						String str = response.readEntity(String.class);
						Osoba o = gson.fromJson(str, Osoba.class);
						System.out.println(o);
						out.writeObject("OK");
						
					} else {
						out.writeObject("NOT_OK");
					}
					System.out.println("ENDED SHOW");
				} else if("END".equals(request)) {
					
				} /*else {
					out.writeObject("ERROR");
				}*/
				
			}
			
			socket.close();
			in.close();
			out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
