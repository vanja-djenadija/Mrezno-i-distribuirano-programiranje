package org.unibl.etf.mdp.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import com.google.gson.Gson;

public class BlogDAO {
	
	public static final String BLOGS_PATH = "." + File.separator + "resources" + File.separator;
	private static ArrayList<Blog> blogs = new ArrayList<>();

	static {
		try {
			File sourceDir = new File(BLOGS_PATH);
			File[] files = sourceDir.listFiles();
			Gson gson = new Gson();
			for (File file : files) {
				try (BufferedReader br = new BufferedReader(new FileReader(file))) {
					String line = "", jsonObject = "";
					while ((line = br.readLine()) != null)
						jsonObject += line;
					Blog blog = gson.fromJson(jsonObject, Blog.class);
					blogs.add(blog);
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static ArrayList<Blog> getAllBlogs() {
		return blogs;
	}

	public static Blog getBlog(String text) {
		for (Blog blog : blogs) {
			if (blog.getText().contains(text))
				return blog;
		}
		return null;
	}

	public static boolean addBlog(Blog blog) {
		Gson gson = new Gson();
		String fileName = "blog_" + new Date().getTime() + ".json";
		try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(BLOGS_PATH + fileName)))) {
			pw.println(gson.toJson(blog));
		} catch (IOException ex) {
			ex.printStackTrace();
			return false;
		}
		synchronized (blogs) {
			blogs.add(blog);	
		}
		return true;
	}

}
