package org.unibl.etf.mdp.model;

public enum ProtocolMessages {

	GET_ALL, 
	SEARCH, 
	ADD, 
	END, 
	OK, 
	NOT_OK,
	INVALID
}
