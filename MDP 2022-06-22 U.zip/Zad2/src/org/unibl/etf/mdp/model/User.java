package org.unibl.etf.mdp.model;

import java.io.Serializable;

public class User implements Serializable {
	
	private String ipAddress, loginTime;

	public User() {
		super();
	}

	public User(String ipAddress, String loginTime) {
		super();
		this.ipAddress = ipAddress;
		this.loginTime = loginTime;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}
	
	

}
