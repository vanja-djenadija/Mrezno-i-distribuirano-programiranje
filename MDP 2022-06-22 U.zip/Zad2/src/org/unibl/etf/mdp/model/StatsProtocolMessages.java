package org.unibl.etf.mdp.model;

public enum StatsProtocolMessages {
	COUNT,
	LIST,
	INVALID,
	END
}
