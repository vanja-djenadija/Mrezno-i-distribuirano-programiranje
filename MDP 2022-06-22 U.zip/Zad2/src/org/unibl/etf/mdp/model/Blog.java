package org.unibl.etf.mdp.model;

import java.io.Serializable;

public class Blog implements Serializable {

	private String title = "";
	private String author = "";
	private String creationTime = "";
	private String text = "";

	public Blog() {
		super();
	}

	public Blog(String title, String author, String creationTime, String text) {
		super();
		this.title = title;
		this.author = author;
		this.creationTime = creationTime;
		this.text = text;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
