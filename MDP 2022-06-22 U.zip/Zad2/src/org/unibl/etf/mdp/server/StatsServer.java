package org.unibl.etf.mdp.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class StatsServer extends Thread{

	public static final int PORT = 9001;

	@Override
	public void run() {
		try (ServerSocket ss = new ServerSocket(PORT)) {
			while (true) {
				Socket socket = ss.accept();
				new StatsServerThread(socket);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

}
