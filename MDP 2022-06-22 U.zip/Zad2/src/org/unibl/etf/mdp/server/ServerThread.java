package org.unibl.etf.mdp.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Date;

import org.unibl.etf.mdp.model.Blog;
import org.unibl.etf.mdp.model.BlogDAO;
import org.unibl.etf.mdp.model.ProtocolMessages;

public class ServerThread extends Thread {
	
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	
	public ServerThread(Socket socket) {
		try {
			this.socket = socket;
			in = new ObjectInputStream(socket.getInputStream());
			out = new ObjectOutputStream(socket.getOutputStream());
			Stats.incrementNumberOfUsers();
			InetSocketAddress sa = (InetSocketAddress) socket.getRemoteSocketAddress();
			Stats.addUser(sa.getHostName(), new Date().toString());
			start();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		try {
			String request = "";
			while (!ProtocolMessages.END.toString().equals(request = (String) in.readObject())) {
				if (request.startsWith(ProtocolMessages.GET_ALL.toString())) {
					out.writeObject(BlogDAO.getAllBlogs());
				} else if (request.startsWith(ProtocolMessages.ADD.toString())) {
					Blog blog = (Blog) in.readObject();
					boolean success = BlogDAO.addBlog(blog);
					if (success)
						out.writeObject(ProtocolMessages.OK.toString());
					else 
						out.writeObject(ProtocolMessages.NOT_OK.toString());
				} else if (request.startsWith(ProtocolMessages.SEARCH.toString())) {
					String text = (String) in.readObject();
					Blog blog = BlogDAO.getBlog(text);
					out.writeObject(blog);
				} else 
					out.writeObject(ProtocolMessages.INVALID.toString());
			}
			socket.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
