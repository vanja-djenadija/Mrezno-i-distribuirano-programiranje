package org.unibl.etf.mdp.server;

public class App {

	public static void main(String[] args) {
		new Server().start();
		new StatsServer().start();
	}

}
