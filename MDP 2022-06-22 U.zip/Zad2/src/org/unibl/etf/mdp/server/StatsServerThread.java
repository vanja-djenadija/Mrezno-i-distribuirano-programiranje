package org.unibl.etf.mdp.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import org.unibl.etf.mdp.model.StatsProtocolMessages;

public class StatsServerThread extends Thread {
	
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	
	public StatsServerThread(Socket socket) {
		try {
			this.socket = socket;
			in = new ObjectInputStream(socket.getInputStream());
			out = new ObjectOutputStream(socket.getOutputStream());
			start();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public void run() {
		try {
			String request = "";
			while (!StatsProtocolMessages.END.toString().equals(request = (String) in.readObject())) {
				if (request.startsWith(StatsProtocolMessages.COUNT.toString())) {
					out.writeObject(Stats.getCount());
				} else if (request.startsWith(StatsProtocolMessages.LIST.toString())) {
					out.writeObject(Stats.getUsers());
				} else {
					out.writeObject(StatsProtocolMessages.INVALID.toString());
				}
			}
			socket.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
