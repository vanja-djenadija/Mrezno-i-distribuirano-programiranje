package org.unibl.etf.mdp.server;

import java.util.ArrayList;

import org.unibl.etf.mdp.model.User;

public class Stats {
	
	private static int count = 0;
	private static ArrayList<User> users = new ArrayList<>();
	private static Object countLock = new Object();
	
	public static void incrementNumberOfUsers() {
		synchronized (countLock) {
			count++;
		}
	}
	
	public static int getCount() {
		return count;
	}
	
	public static void addUser(String ip, String time) {
		synchronized (users) {
			users.add(new User(ip, time));
		}
	}
	
	public void removeUser(String ip) {
		synchronized (users) {
			int index = -1;
			for (int i = 0; i < users.size(); i++)
				if (users.get(i).getIpAddress().equals(ip))
					index = i;
			users.remove(index);
		}
	}
	
	public static ArrayList<User> getUsers() {
		return users;
	}

}
