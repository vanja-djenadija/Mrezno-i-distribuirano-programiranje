package org.unibl.etf.mdp.client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

import org.unibl.etf.mdp.model.Blog;
import org.unibl.etf.mdp.model.ProtocolMessages;
import org.unibl.etf.mdp.model.StatsProtocolMessages;
import org.unibl.etf.mdp.model.User;

public class Client {
	
	public static final String HOST = "127.0.0.1";
	public static final int BLOG_PORT = 9000, STATS_PORT = 9001;
	
	public static void main(String[] args) {
		try (Socket sock = new Socket(HOST, BLOG_PORT)) {
			ObjectOutputStream out = new ObjectOutputStream(sock.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(sock.getInputStream());
			out.writeObject(ProtocolMessages.ADD.toString());
			out.writeObject(new Blog("title1", "author1", new Date().toString(), "Blog 1 contains text 1."));
			System.out.println((String) in.readObject());
			out.writeObject(ProtocolMessages.GET_ALL.toString());
			ArrayList<Blog> blogs = (ArrayList<Blog>) in.readObject();
			for (Blog b : blogs)
				System.out.println(b.getTitle());
			out.writeObject(ProtocolMessages.SEARCH.toString());
			out.writeObject("contains");
			Blog b = (Blog) in.readObject();
			System.out.println(b.getText());
			out.writeObject(ProtocolMessages.END.toString());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		try (Socket sock = new Socket(HOST, STATS_PORT)) {
			ObjectOutputStream out = new ObjectOutputStream(sock.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(sock.getInputStream());
			out.writeObject(StatsProtocolMessages.COUNT.toString());
			System.out.println((int) in.readObject());
			out.writeObject(StatsProtocolMessages.LIST.toString());
			ArrayList<User> users = (ArrayList<User>) in.readObject();
			for (User u : users)
				System.out.println(u.getIpAddress() + " " + u.getLoginTime());
			out.writeObject(ProtocolMessages.END.toString());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
