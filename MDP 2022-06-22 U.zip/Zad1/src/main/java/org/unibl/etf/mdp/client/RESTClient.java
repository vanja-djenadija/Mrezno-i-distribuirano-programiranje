package org.unibl.etf.mdp.client;

import java.io.IOException;
import java.util.ArrayList;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.mdp.model.Product;

public class RESTClient {
	
	public static final String URI_BASE = "http://localhost:8080/Zad1/api/products/";
	
	public static void main(String[] args) throws IOException {
		
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(URI_BASE);
		Response response = target.request(MediaType.APPLICATION_JSON).get();
		System.out.println(response.getStatus());
		target = client.target(URI_BASE + "123");
		response = target.request(MediaType.APPLICATION_JSON).get();
		System.out.println(response.getStatus());
		target = client.target(URI_BASE);
		ArrayList<String> code = new ArrayList<>();
		code.add("4321");
		Product p = new Product(code, "name2", "desc2", "type2");
		response = target.request().post(Entity.entity(p, MediaType.APPLICATION_JSON));
		target = client.target(URI_BASE + "4321");
		response = target.request().delete();
		System.out.println(response.getStatus());
	}

}
