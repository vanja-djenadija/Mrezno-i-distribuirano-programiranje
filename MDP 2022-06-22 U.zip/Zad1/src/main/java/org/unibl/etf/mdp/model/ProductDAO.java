package org.unibl.etf.mdp.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

public class ProductDAO {

	public static final String PRODUCTS_PATH = "." + File.separator + "resources" + File.separator;
	private static ArrayList<Product> products = new ArrayList<>();

	static {
		try {
			File sourceDir = new File(PRODUCTS_PATH);
			File[] files = sourceDir.listFiles();
			Kryo kryo = new Kryo();
			kryo.register(Product.class);
			for (File file : files) {
				try (Input in = new Input(new FileInputStream(file))) {
					Product product = (Product) kryo.readClassAndObject(in);
					products.add(product);
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static ArrayList<Product> getAllProducts() {
		return products;
	}

	public static Product getProductByCode(String code) {
		for (Product product : products) {
			for (String productCode : product.getCodes())
				if (productCode.equals(code))
					return product;
		}
		return null;
	}

	public static boolean addProduct(Product product) {
		for (String newCode : product.getCodes()) {
			for (Product p : products) {
				for (String productCode : p.getCodes())
					if (productCode.equals(newCode))
						return false;
			}
		}
		Kryo kryo = new Kryo();
		kryo.register(Product.class);
		String fileName = "product";
		for (String code : product.getCodes())
			fileName += "_" + code;
		fileName += ".bin";
		try (Output out = new Output(new FileOutputStream(PRODUCTS_PATH + fileName))) {
			kryo.writeClassAndObject(out, product);
		} catch (IOException ex) {
			ex.printStackTrace();
			return false;
		}
		products.add(product);
		return true;
	}

	public static Product deleteProduct(String code) {
		Product product = getProductByCode(code);
		if (product == null)
			return null;
		Kryo kryo = new Kryo();
		kryo.register(Product.class);
		String fileName = "product";
		for (String productCode : product.getCodes())
			fileName += "_" + productCode;
		fileName += ".bin";
		try {
			File file = new File(PRODUCTS_PATH + fileName);
			if (file.delete()) {
				int index = 0;
				for (int i = 0; i < products.size(); i++)
					for (String productCode : product.getCodes())
						if (productCode.equals(code))
							index = i;
				products.remove(index);
				return product;
			} else
				return null;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

}
