package org.unibl.etf.mdp.service;

import java.util.ArrayList;

import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.mdp.model.Product;
import org.unibl.etf.mdp.model.ProductDAO;

@Path("products")
public class RESTService {
	
	private final int GET_NOT_FOUND = 404;
	private final int ADD_SUCCESS = 201;
	private final int ADD_NOT_SUCCESS = 500;
	private final int DELETE_NOT_FOUND = 404;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllProducts() {
		ArrayList<Product> products = ProductDAO.getAllProducts();
		return Response.ok().entity(products).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{code}")
	public Response getProductByCode(@PathParam("code") String code) {
		Product product = ProductDAO.getProductByCode(code);
		if (product == null) 
			return Response.status(GET_NOT_FOUND).build();
		else
			return Response.ok().entity(product).build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addProduct(Product product) {
		boolean success = ProductDAO.addProduct(product);
		if (success)
			return Response.status(ADD_SUCCESS).build();
		else
			return Response.status(ADD_NOT_SUCCESS).build();
	}
	
	@DELETE
	@Path("{code}")
	public Response deleteProduct(@PathParam("code") String code) {
		Product product = ProductDAO.deleteProduct(code);
		if (product == null)
			return Response.status(DELETE_NOT_FOUND).build();
		else
			return Response.ok().entity(product).build();
	}
	
}
