package org.unibl.etf.mdp.model;

import java.util.ArrayList;

public class Product {
	private ArrayList<String> codes = new ArrayList<>();
	private String name = "";
	private String description = "";
	private String type = "";

	public Product() {
		super();
	}

	public Product(ArrayList<String> codes, String name, String description, String type) {
		super();
		this.codes = codes;
		this.name = name;
		this.description = description;
		this.type = type;
	}

	public ArrayList<String> getCodes() {
		return codes;
	}

	public void setCodes(ArrayList<String> codes) {
		this.codes = codes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
