package org.unibl.etf.mdp.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.mdp.model.Korisnik;
import org.unibl.etf.mdp.model.Poruka;
import org.unibl.etf.mdp.model.PorukaServis;

@Path("/putanja1")
public class RESTService {

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response procitajPoruke(@PathParam("id")int id) {
		System.out.println("IN");
		return Response.status(200).entity(PorukaServis.pregledajPoruke(id)).build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response posaljiPoruku(Poruka p) {
		System.out.println("INNN!");
		if(PorukaServis.posaljiPoruku(p)) {
			return Response.status(201).build();
		} else {
			return Response.status(500).build();
		}
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response pregledajKorisnike(Korisnik k) {
		return Response.status(200).entity(PorukaServis.pregledajKorisnike(k.getId())).build();
	}
	
	@DELETE
	@Path("/{id}/{brPor}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response obrisiPoruke(@PathParam("id")int id, @PathParam("brPor")int brojPoruka) {
		return Response.status(200).entity(PorukaServis.obrisiPoruke(id, brojPoruka)).build();
	}
	
	
	
}
