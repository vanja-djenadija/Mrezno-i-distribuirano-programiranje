package org.unibl.etf.model;

public class Info {

	private long run_time;
	private int total_clients;
	public Info(long run_time, int total_clients) {
		super();
		this.run_time = run_time;
		this.total_clients = total_clients;
	}
	public Info() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getRun_time() {
		return run_time;
	}
	public void setRun_time(long run_time) {
		this.run_time = run_time;
	}
	public int getTotal_clients() {
		return total_clients;
	}
	public void setTotal_clients(int total_clients) {
		this.total_clients = total_clients;
	}
	
	
	
}
