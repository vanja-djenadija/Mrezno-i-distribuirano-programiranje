package org.unibl.etf.server;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class Server {

	public static final int SERVER_PORT=5000;
	
	public static final long START_TIME = new Date().getTime();
	
	public static int NUM_CLIENTS=0;
	
	public static void main(String[] args) {
		
		
		try {
			new MulticastClass().start();
			ServerSocket ss = new ServerSocket(SERVER_PORT);
			System.out.println("Server pokrenut!");
			while(true) {
				Socket s = ss.accept();
				System.out.println("Klijent prihvacen!");
				NUM_CLIENTS++;
				new ServerThread(s);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
