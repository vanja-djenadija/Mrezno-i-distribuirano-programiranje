package org.unibl.etf.server;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.ServerSocket;
import java.util.Date;

public class MulticastClass extends Thread {

	public static final String MULTICAST_ADDRESS="224.0.0.11";
	MulticastSocket socket;
	InetAddress address;
	public MulticastClass() {
		try {
			address = InetAddress.getByName(MULTICAST_ADDRESS);
			socket = new MulticastSocket();
			socket.joinGroup(address);
		} catch(Exception e) {
			
		}
	}
	
	@Override
	public void run() {
		while(true) {
			try {
				Date date = new Date();
				int hours = date.getHours();
				int minutes = date.getMinutes();
				String mssg = hours+":"+minutes+"#"+Server.NUM_CLIENTS;
				byte[] buff = new byte[mssg.getBytes().length];
				buff = mssg.getBytes();
				DatagramPacket packet = new DatagramPacket(buff, buff.length, address, 20000);
				socket.send(packet);
				Thread.sleep(2000);
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
}
