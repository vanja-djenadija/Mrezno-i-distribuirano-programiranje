package org.unibl.etf.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Date;

import org.unibl.etf.model.Info;

import com.google.gson.Gson;

public class ServerThread extends Thread {

	private PrintWriter out;
	private BufferedReader in;
	private Socket socket;
	private boolean sabiranje=false;
	private int rezultat = 0;
	
	public ServerThread(Socket s) {
		try {
			socket = s;
			out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
			in = new BufferedReader(new InputStreamReader(s.getInputStream()));
		} catch(Exception e) {
			e.printStackTrace();
		}
		start();
	}
	
	@Override
	public void run() {
		try {
			String mssg = "";
			while(!"END".equals(mssg)) {
				mssg = in.readLine();
				if("GET_STATUS".equals(mssg)) {
					System.out.println("IN STATUS!");
					Gson gson = new Gson();
					Info info = new Info((new Date().getTime()-Server.START_TIME)/1000, Server.NUM_CLIENTS);
					out.println(gson.toJson(info));
				} else if("ADD".equals(mssg)) {
					sabiranje = true;
					out.println("OK");
				} else if(mssg != null && mssg.startsWith("NUMBER")) {
					if(sabiranje) {
						String[] parse = mssg.split("#");
						rezultat += Integer.parseInt(parse[1]);
						out.println("OK");
					}
				} else if("TOTAL".equals(mssg)) {
					out.println("TOTAL#"+rezultat);
					rezultat = 0;
				}
			}
			socket.close();
			in.close();
			out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
