package org.unibl.etf.model;

import java.io.Serializable;
import java.util.Objects;

public class Phone implements Serializable {

	private String phoneNum;
	private String type;
	private double value;
	private String internet;
	public Phone(String phoneNum, String type, double value, String internet) {
		super();
		this.phoneNum = phoneNum;
		this.type = type;
		this.value = value;
		this.internet = internet;
	}
	public Phone() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	public String getInternet() {
		return internet;
	}
	public void setInternet(String internet) {
		this.internet = internet;
	}
	@Override
	public String toString() {
		return "Phone [phoneNum=" + phoneNum + ", type=" + type + ", value=" + value + ", internet=" + internet + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(phoneNum);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Phone other = (Phone) obj;
		return Objects.equals(phoneNum, other.phoneNum);
	}
	
	
	public Phone(String pn) {
		phoneNum = pn;
	}
	
}
