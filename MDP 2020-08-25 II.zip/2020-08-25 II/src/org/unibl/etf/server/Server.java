package org.unibl.etf.server;

import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static final int PORT=5000;
	
	public static void main(String[] args) {
		try {
			ServerSocket ss = new ServerSocket(PORT);
			System.out.println("Server started.");
			while(true) {
				Socket s = ss.accept();
				System.out.println("Client accepted!");
				new ServerThread(s);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
