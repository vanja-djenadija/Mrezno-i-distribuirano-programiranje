package org.unibl.etf.rest;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.model.Registracija;
import org.unibl.etf.model.Vozilo;
import org.unibl.etf.model.VoziloServis;

@Path("/vozilo")
public class RestServis1 {

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response dodajVozilo(Vozilo v) {
		if(VoziloServis.kreirajVozilo(v)) {
			return Response.status(201).build();
		} else {
			return Response.status(500).build();
		}
	}
	
	@POST
	@Path("/{reg}")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response dodajRegistraciju(Registracija r, @PathParam("reg")String reg) {
		if(VoziloServis.dodajRegistraciju(reg, r)) {
			return Response.status(201).build();
		} else {
			return Response.status(500).build();
		}
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response dohvatiSvaVozila() {
		ArrayList<Vozilo>  sva = VoziloServis.svaVozila();
		if(sva != null) {
			return Response.status(200).entity(sva).build();
		} else {
			return Response.status(404).build();
		}
	}
	
	@GET
	@Path("/{reg}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dohvatiNaOsnovuRegBroja(@PathParam("reg")String reg) {
		Vozilo  sva = VoziloServis.dobijNaOsnovuRegBroja(reg);
		if(sva != null) {
			return Response.status(200).entity(sva).build();
		} else {
			return Response.status(404).build();
		}
	}
	
	
	
}
