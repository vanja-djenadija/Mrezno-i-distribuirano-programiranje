package org.unibl.etf.model;

import java.util.ArrayList;

public class Vozilo {

	private String regBroj;
	private String proizvodjac;
	private String model;
	private ArrayList<Registracija> registracije = new ArrayList<>();
	public Vozilo(String regBroj, String proizvodjac, String model, ArrayList<Registracija> registracije) {
		super();
		this.regBroj = regBroj;
		this.proizvodjac = proizvodjac;
		this.model = model;
		this.registracije = registracije;
	}
	public Vozilo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getRegBroj() {
		return regBroj;
	}
	public void setRegBroj(String regBroj) {
		this.regBroj = regBroj;
	}
	public String getProizvodjac() {
		return proizvodjac;
	}
	public void setProizvodjac(String proizvodjac) {
		this.proizvodjac = proizvodjac;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public ArrayList<Registracija> getRegistracije() {
		return registracije;
	}
	public void setRegistracije(ArrayList<Registracija> registracije) {
		this.registracije = registracije;
	}
	@Override
	public String toString() {
		return "Vozilo [regBroj=" + regBroj + ", proizvodjac=" + proizvodjac + ", model=" + model + ", registracije="
				+ registracije + "]";
	}
	
	
	
}
