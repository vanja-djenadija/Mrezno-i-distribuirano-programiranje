package org.unibl.etf.client;

import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.model.Registracija;
import org.unibl.etf.model.Vozilo;

public class Klijent {

	private static String URI="http://localhost:8080/21-7-2020-drugi/api/vozilo/";
	private static String URI2="http://localhost:8080/21-7-2020-drugi/api/vozilo2/";
	
	public static void main(String[] args) {
		
		try {
			
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(URI);
			Response r = target.request(MediaType.APPLICATION_JSON).get();
			System.out.println(r.getStatus());
			
			/*ArrayList<Registracija> reg = new ArrayList<>();
			reg.add(new Registracija(new Date(), 300000, "Najbolji222"));
			Vozilo v = new Vozilo("rb22", "pr2", "mo2", reg);
			target = client.target(URI);
			r = target.request(MediaType.APPLICATION_JSON).post(Entity.entity(v, MediaType.APPLICATION_JSON));
			System.out.println(r.getStatus());*/
			
			/*Registracija registracija = new Registracija(new Date(), 310000, "Najboljiasfasfasf222");
			target = client.target(URI+"rb22");
			r = target.request(MediaType.APPLICATION_JSON).post(Entity.entity(registracija, MediaType.APPLICATION_JSON));
			System.out.println(r.getStatus());*/
			
			target = client.target(URI+"rb22");
			r = target.request(MediaType.APPLICATION_JSON).get();
			String response = r.readEntity(String.class);
			System.out.println(response);
			
			target = client.target(URI2);
			r = target.request(MediaType.APPLICATION_JSON).get();
			String response2 = r.readEntity(String.class);
			System.out.println(response2);
			
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

}
