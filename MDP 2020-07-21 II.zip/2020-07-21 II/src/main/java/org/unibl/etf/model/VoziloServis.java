package org.unibl.etf.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

import com.google.gson.Gson;

public class VoziloServis {

	private static String PUTANJA="."+File.separator+"vozila.json";
	
	public static void populisi() {
		try {
			Gson gson = new Gson();
			PrintWriter pw = new PrintWriter(new File(PUTANJA));
			for(int i=0; i<10; i++) {
				Registracija r = new Registracija(new Date(), 150000+i*20, "Komentar"+i);
				ArrayList<Registracija> reg = new ArrayList<>();
				reg.add(r);
				Vozilo v = new Vozilo("regBroj"+i, "proizvodjac"+i, "model"+i, reg);
				pw.println(gson.toJson(v));
			}
			
			pw.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static Vozilo dobijNaOsnovuRegBroja(String regBroj) {
		try {
			
			ArrayList<Vozilo> vozila = svaVozila();
			for(Vozilo v : vozila) {
				if(v.getRegBroj().equals(regBroj)) {
					return v;
				}
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static ArrayList<Vozilo> svaVozila() {
		ArrayList<Vozilo> vozila = new ArrayList<>();
		try {
			Gson gson = new Gson();
			BufferedReader bf = new BufferedReader(new FileReader(new File(PUTANJA)));
			String procitaj="";
			while((procitaj=bf.readLine()) != null) {
				Vozilo v = gson.fromJson(procitaj, Vozilo.class);
				vozila.add(v);
			}
			bf.close();
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		return vozila;
	}
	
	public static boolean kreirajVozilo(Vozilo v) {
		
		try {
			ArrayList<Vozilo> vozila = svaVozila();
			for(Vozilo v1 : vozila) {
				if(v1.getRegBroj() == v.getRegBroj()) return false;
			}
			Gson gson = new Gson();
			PrintWriter pw = new PrintWriter(new File(PUTANJA));
			pw.println(gson.toJson(v));
			for(Vozilo v2 : vozila) {
				pw.println(gson.toJson(v2));
			}
			pw.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean dodajRegistraciju(String regBroj, Registracija r) {
		try {
			ArrayList<Vozilo> vozila = svaVozila();
			boolean found = false;
			for(Vozilo v : vozila) {
				if(v.getRegBroj().equals(regBroj)) {
					v.getRegistracije().add(r);
					
					found = true;
				}
			}
			if(found) {
				Gson gson = new Gson();
				PrintWriter pw = new PrintWriter(new File(PUTANJA));
				for(Vozilo v2 : vozila) {
					pw.println(gson.toJson(v2));
				}
				pw.close();
				return true;
			}
			
			return false;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public static ArrayList<Vozilo> spornaVozila() {
		ArrayList<Vozilo> vozila = new ArrayList<>();
		boolean jedan=false;
		try {
			ArrayList<Vozilo> sva = svaVozila();
			for(Vozilo v : sva) {
				Vozilo novo = new Vozilo();
				boolean nasao = false;
				ArrayList<Registracija> registracije = v.getRegistracije();
				for(int i=0; i<registracije.size()-1; i++) {
					//ovdje se porede samo dvije uzastopne, ne sve, nije dobro ali radi bar ovo
					if(registracije.get(i).getKilometraza() > registracije.get(i+1).getKilometraza() 
							&& registracije.get(i).getDatumRegistracije().getTime() > registracije.get(i).getDatumRegistracije().getTime()) {
						jedan = true;
						if(!nasao) {
							novo.setRegBroj(v.getRegBroj());
							novo.setModel(v.getModel());
							novo.setProizvodjac(v.getProizvodjac());
							novo.getRegistracije().add(registracije.get(i));
							novo.getRegistracije().add(registracije.get(i+1));
							nasao=true; 
						} else {
							novo.getRegistracije().add(registracije.get(i));
							novo.getRegistracije().add(registracije.get(i+1));
						}
					}
				}
				if(nasao) {
					vozila.add(novo);
				}
			}
			if(jedan) {
				return vozila;
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static ArrayList<ListaModel> dohvatiSortirane(int kriterijum) {
		ArrayList<ListaModel> model = new ArrayList<>();
		try {
			ArrayList<Vozilo> vozila = svaVozila();
			Vozilo[] voz = new Vozilo[vozila.size()];
			for(int i=0; i<voz.length; i++) {
				voz[i] = new Vozilo();
				voz[i] = vozila.get(i);
				//System.out.println(voz[i]);
			}
			Arrays.sort(voz, new Comparator<Vozilo>() {

				@Override
				public int compare(Vozilo o1, Vozilo o2) {
					if(kriterijum == 1) {
						if(o1.getRegistracije().get(o1.getRegistracije().size()-1).getDatumRegistracije().getTime() 
								>  o2.getRegistracije().get(o2.getRegistracije().size()-1).getDatumRegistracije().getTime()) {
							return 1;
						} else if(o1.getRegistracije().get(o1.getRegistracije().size()-1).getDatumRegistracije().getTime() 
								 < o2.getRegistracije().get(o2.getRegistracije().size()-1).getDatumRegistracije().getTime()) {
							return -1;
						} else
							return 0;
					} else {
						if(o1.getRegistracije().get(o1.getRegistracije().size()-1).getDatumRegistracije().getTime() 
								< o2.getRegistracije().get(o2.getRegistracije().size()-1).getDatumRegistracije().getTime()) {
							return 1;
						} else if(o1.getRegistracije().get(o1.getRegistracije().size()-1).getDatumRegistracije().getTime() 
								 > o2.getRegistracije().get(o2.getRegistracije().size()-1).getDatumRegistracije().getTime()) {
							return -1;
						} else
							return 0;
					}
					
				}
				
			});
			for(int i=0; i<voz.length; i++) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(voz[i].getRegistracije().get(voz[i].getRegistracije().size()-1).getDatumRegistracije());
				calendar.add(Calendar.YEAR, 1);
				Date newDate = calendar.getTime();
				System.out.println(voz[i]);
				model.add(new ListaModel(voz[i].getRegBroj(), newDate));
			}

			/*for(int i=0; i<voz.length; i++) {
				model.add(voz[i]);
				System.out.println(model.get(i));
			}*/
			return model;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
 	
	public static void main(String[] args) {
		
		//populisi();
		/*ArrayList<Vozilo> vozila = svaVozila();
		for(Vozilo v : vozila) {
			System.out.println(v);
		}*/
		//Vozilo v = dobijNaOsnovuRegBroja("regBroj1"); System.out.println(v);
		
		/*ArrayList<Registracija> r = new ArrayList<>();
		r.add(new Registracija(new Date(), 300000, "Najbolji"));
		Vozilo v = new Vozilo("rb", "pr", "mo", r);
		boolean status = kreirajVozilo(v);
		System.out.println(status);*/
		
		/*Registracija r = new Registracija(new Date(), 299000, "Najbolji");
		dodajRegistraciju("regBroj2", r);*/
		
		/*ArrayList<Vozilo> vozila = spornaVozila();
		for(Vozilo v : vozila) {
			System.out.println(v);
		}*/
		
		ArrayList<ListaModel> sortirani = dohvatiSortirane(1);
		for(ListaModel v : sortirani) {
			System.out.println(sortirani);
		}
	}

}
