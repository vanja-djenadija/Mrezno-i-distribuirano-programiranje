package org.unibl.etf.model;

public class Model {

	private String result;
	private String action;
	public Model(String result, String action) {
		super();
		this.result = result;
		this.action = action;
	}
	public Model() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	@Override
	public String toString() {
		return "Model [result=" + result + ", action=" + action + "]";
	}
	
	
	
}
