package org.unibl.etf.rmi;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;

public interface RMIInterface extends Remote {

	public int addResult(int a, int b, int c) throws RemoteException;
	public String getDate() throws RemoteException;
	public boolean saveText(String filename, String text) throws RemoteException;
	public String readFile(String filename) throws RemoteException; 
	
}
