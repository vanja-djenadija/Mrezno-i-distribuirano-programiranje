package org.unibl.etf.client;

import java.io.File;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

import org.unibl.etf.rmi.RMIInterface;

public class Client {

	public static  void main(String[] args) {
		
		try {
			System.setProperty("java.security.policy", "."+File.separator+"policy.txt");
			if(System.getSecurityManager() == null) {
				System.setSecurityManager(new SecurityManager());
			}
			Registry registry = LocateRegistry.getRegistry(1099);
			RMIInterface stub = (RMIInterface)registry.lookup("Stub");
			String input="";
			Scanner scan = new Scanner(System.in);
			while(!"END".equals(input)) {
				input = scan.nextLine();
				if(input.startsWith("SUM")) {
					String[] parse = input.split(","); //forma 4,5,6 bez zareza
					int a = Integer.valueOf(parse[0].substring(parse[0].length()-1, parse[0].length()));
					int b = Integer.valueOf(parse[1]);
					int c = Integer.valueOf(parse[2]);
					int res = stub.addResult(a, b, c);
					System.out.println("RESULT (a+b+c) = " + res);
				} else if("GET DATE".equals(input)) {
					String date = stub.getDate();
					System.out.println("DATE IS " + date);
				} else if(input.startsWith("SAVE")) {
					String[] split = input.split(" ");
					String fileName = split[1];
					String text = split[2];
					if(stub.saveText(fileName, text)) {
						System.out.println("Success!");
					} else {
						System.out.println("No success!");
					}
				} else if(input.startsWith("READ")) {
					String[] split = input.split(" ");
					String content = stub.readFile(split[1]);
					System.out.println("CONTENT READ = " + content);
				} else {
					System.out.println("Nepoznata opcija");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
