package org.unibl.etf.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

import org.unibl.etf.messages.ProtocolMessage;
import org.unibl.etf.server.Server;

public class Alice {

	public static void main(String[] args) {
		
		try {
			/*File f = new File("./a.txt");
			System.out.println(f.exists());*/
			Socket s = new Socket(InetAddress.getByName("localhost"), Server.PORT);
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
			Scanner scan = new Scanner(System.in);
			String response = "";
			out.println("Alice");
			response = in.readLine();
			if(ProtocolMessage.NO_FILE.equals(response)) {
				System.out.println("NO FILE, ENTER 5 OR MORE LINES, END FOR EXIT!");
				String input=""; int counter = 0;
				String text = "";
				while(!"END".equals(input)) {
					input = scan.nextLine();
					if(!"END".equals(input)) {
						
						text += input;
						text += "/";
						counter++;
					}
					
				}
				if(counter < 5) {				
					throw new Exception("Need >= 5...");
				}
				out.println(ProtocolMessage.UPLOAD);
				out.println(text);
				System.out.println("Answer: ");
				String answer = scan.nextLine();
				out.println(answer);
			} else {
				out.println(ProtocolMessage.DOWNLOAD);
				System.out.println("Content = " + in.readLine());
				System.out.println("Key = " + in.readLine());
				System.out.println("Does match: " + in.readLine());
			}
			s.close();
			scan.close();
			out.close();
			in.close();
			s.close();
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

}
