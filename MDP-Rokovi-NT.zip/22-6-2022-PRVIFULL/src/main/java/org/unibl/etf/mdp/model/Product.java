package org.unibl.etf.mdp.model;

import java.util.ArrayList;

public class Product {

	private ArrayList<String> sifre = new ArrayList<>();
	private String naziv;
	private String opis;
	private String tip;
		
	public Product() {
		super();
	}

	public Product(ArrayList<String> sifre, String naziv, String opis, String tip) {
		super();
		this.sifre = sifre;
		this.naziv = naziv;
		this.opis = opis;
		this.tip = tip;
	}

	public ArrayList<String> getSifre() {
		return sifre;
	}

	public void setSifre(ArrayList<String> sifre) {
		this.sifre = sifre;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}

	@Override
	public String toString() {
		return "Product [sifre=" + sifre + ", naziv=" + naziv + ", opis=" + opis + ", tip=" + tip + "]";
	}
	
	
	
}
