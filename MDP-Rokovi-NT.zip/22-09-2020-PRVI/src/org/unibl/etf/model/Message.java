package org.unibl.etf.model;

import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable {

	private String text;
	private Date time;
	
	public Message() {
		super();
	}
	
	public Message(String text, Date time) {
		super();
		this.text = text;
		this.time = time;
	}
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	public Date getTime() {
		return time;
	}
	
	public void setTime(Date time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Message [text=" + text + ", time=" + time + "]";
	}
	
	
	
}
