package org.unibl.etf.client;

import java.io.File;
import java.io.PrintWriter;

public class Test {

	
	public static void main(String[] args) {
		try {
			PrintWriter pw = new PrintWriter(new File("a.txt"));
			pw.println("a");
			pw.println("b");
			pw.println("c");
			pw.println("d");
			pw.println("e");
			pw.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
