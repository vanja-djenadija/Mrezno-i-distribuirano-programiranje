package org.unibl.etf.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class ClientApp {

	public static final String M_HOST="224.0.0.11";
	public static final String PATH="."+File.separator+"KPoruke"+File.separator;
	public static final String PATH_ALL="."+File.separator+"Poruke"+File.separator;
	
	public static void main(String[] args) {
		System.out.println(args.length);
		for(String arg : args) {
			System.out.println(arg);
		}
		try {
			InetAddress address = InetAddress.getByName(M_HOST);
			MulticastSocket socket = new MulticastSocket();
			socket.joinGroup(address);
			Scanner scan = new Scanner(System.in);
			String input = "";
			while(!"END".equals(input)) {
				System.out.println("Option (SEND/SEND5/END)");
				input = scan.nextLine();
				if("SEND".equals(input)) {
					System.out.println("Your text: ");
					String text = "";
					text = scan.nextLine();
					System.out.println("Do you want to send the message (y/n)");
					String choice = "";
					choice = scan.nextLine();
					if("y".equalsIgnoreCase(choice)) {
						byte[] buff = new byte[text.getBytes().length];
						buff = text.getBytes();
						DatagramPacket packet = new DatagramPacket(buff, buff.length, address, 20000);
						socket.send(packet);
						long time = new Date().getTime();
						String fileName = PATH+"P_"+time;
						File f = new File(fileName);
						PrintWriter pw = new PrintWriter(f);
						pw.println(text);
						pw.close();
						pw = new PrintWriter(new File(PATH_ALL+"P_"+time));
						pw.println(text);
						pw.close();
					} else if("n".equalsIgnoreCase(choice)) {
						long time = new Date().getTime();
						String fileName = PATH+"N_"+time;
						File f = new File(fileName);
						PrintWriter pw = new PrintWriter(f);
						pw.println(text);
						pw.close();
						pw = new PrintWriter(new File(PATH_ALL+"N_"+time));
						pw.println(text);
						pw.close();
						System.out.println("FINISHED");
					} else {
						System.out.println("Has to be y or n!");
					}
				} else if("SEND5".equals(input)) {
					String fileName = PATH_ALL;
					File f = new File(fileName);
					File[] files = f.listFiles();
					int counter = 0;
					ArrayList<String> messages = new ArrayList<>();
					
					//Trebalo bi ovako
					if(files.length <= 5) {
						//ispisi sve kao dolje
					} else {
						for(int i=files.length-1; i>=files.length-5; i--) {
							//iscitaj fajl i posalji
						}
					}
					
					for(File file : files) {
						BufferedReader reader = new BufferedReader(new FileReader(file));
						String read="", text="";
						while((read=reader.readLine()) != null) {
							text+=read;
						}
						reader.close();
						messages.add(text);
						counter++;
						if(counter > 4) break;
						
					}
					for(String message : messages) {
						byte[] buff = new byte[message.getBytes().length];
						buff = message.getBytes();
						DatagramPacket packet = new DatagramPacket(buff, buff.length, address, 20000);
						socket.send(packet);
					}
				} else if("END".equals(input)) {
					
				} else {
					System.out.println("Mistake!Try again!");
				}
			}
			socket.close();
			scan.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
