package org.unibl.etf.server;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.Scanner;

import org.unibl.etf.client.ClientApp;
import org.unibl.etf.model.Message;

import com.google.gson.Gson;

public class Server {
	public static MulticastSocket socket;
	public static int PORT=5000;
	public static void main(String[] args) {
		
		try {
			socket = new MulticastSocket(20000);
			InetAddress address = InetAddress.getByName(ClientApp.M_HOST);
			socket.joinGroup(address);
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					try {
						while(true) {
							//poruka koja je procitana se opet upise u fajl
							//jer korisnik nema izbora, svakako mu se posalje
							byte[] buff = new byte[256];
							DatagramPacket packet = new DatagramPacket(buff, buff.length);
							socket.receive(packet);
							String s2 = new String(buff);
							String s = new String(buff, 0, s2.indexOf(0));
							System.out.println(s.length()); //ispis primljene poruke
							Message m = new Message(s, new Date());
							if(s.length() <= 49) {
								XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(new FileOutputStream(new File("."+File.separator+"Vozac_"+new Date().getTime()+".xml"))));
								encoder.writeObject(m);
								encoder.close();
							} else {
								Gson gson = new Gson();
								PrintWriter pw = new PrintWriter(new File("Vozac_"+new Date().getTime()+".json"));
								pw.println(gson.toJson(m));
								pw.close();
							}	
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
					
					
				}
			}).start();
			String userInput="";
			Scanner scan = new Scanner(System.in);
			while(!"END".equals(scan)) {
				userInput = scan.nextLine();
				if("READ".equals(userInput)) {
					//provjeri da li je poruka procitana na osnovu upisanih poruka u fajl korisnika (sve sto pocinje sa Vozac)
					File f = new File("."+File.separator);
					File f1 = new File("./Poruke/");
					File[] files2 = f1.listFiles();
					File[] files = f.listFiles();
					Message m = new Message();
					for(File file1 : files) {
							if(file1.getName().startsWith("Vozac")) {
								if(file1.getName().endsWith("json")) {
									Gson gson = new Gson();
									BufferedReader br = new BufferedReader(new FileReader(file1));
									String read="",text="";
									while((read=br.readLine()) != null) {
										text+=read;
									}
									m = gson.fromJson(text, Message.class);
									br.close();
								} else {
									XMLDecoder decoder = new XMLDecoder(new FileInputStream(file1));
									m = (Message) decoder.readObject();
									decoder.close();
								}
							}
							if(file1.getName().startsWith("Vozac"))  {
								boolean procitana = false;
								String tmp = "";
								for(File file2 : files2) {
									BufferedReader in = new BufferedReader(new FileReader(file2));
									String read="",text="";
									while((read=in.readLine()) != null) {
										text+=read;
									}
									if(m.getText()!=null && m.getText().equals(text)) {
										procitana = true;
									}
									in.close();
								}
								if(!procitana && m.getText() != null) {
									System.out.println("NEPROCITANA PORUKA " + m);
									//upisati je opet kao json ili xml, isti princip kao gore
								} else if(procitana) {
									procitana = false;
								}
							}
							
					}
					
				}
			}
		} catch(Exception e) {
			socket.close();
			e.printStackTrace();
		}
	}
}
