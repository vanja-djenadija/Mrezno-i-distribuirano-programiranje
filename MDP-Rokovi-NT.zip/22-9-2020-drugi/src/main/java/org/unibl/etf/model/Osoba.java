package org.unibl.etf.model;

import java.io.Serializable;
import java.util.Objects;

public class Osoba implements Serializable {

	private String jmb;
	private String ime;
	private String prezime;
	public Osoba(String jmb, String ime, String prezime) {
		super();
		this.jmb = jmb;
		this.ime = ime;
		this.prezime = prezime;
	}
	public Osoba(String jmb) {
		this.jmb=jmb;
	}
	public Osoba() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getJmb() {
		return jmb;
	}
	public void setJmb(String jmb) {
		this.jmb = jmb;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	@Override
	public String toString() {
		return "Osoba [jmb=" + jmb + ", ime=" + ime + ", prezime=" + prezime + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(jmb);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Osoba other = (Osoba) obj;
		return Objects.equals(jmb, other.jmb);
	}
	
	
	
}
