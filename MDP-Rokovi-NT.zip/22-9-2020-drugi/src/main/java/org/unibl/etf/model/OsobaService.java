package org.unibl.etf.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;

public class OsobaService {

	public static final String PATH="."+File.separator+"/osobe.bin";
	
	public static boolean addPerson(Osoba osoba) {
		try {
			ArrayList<Osoba> data = readData();
			if(data.contains(osoba)) {
				File f = new File(PATH);
				f.delete();
				changeData(osoba, data);
			} else {
				data.add(osoba);
				File f = new File(PATH);
				f.delete();
			}
			
			Kryo kryo = new Kryo();
	        kryo.register(Osoba.class);
	        Output out = new Output(new FileOutputStream(new File(PATH)));   
	        kryo.writeObject(out, data); 
	        out.close();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	public static Osoba getPerson(String jmb) {
		try {
			ArrayList<Osoba> osobe = readData();
			Osoba o = new Osoba(jmb);
			int index = osobe.indexOf(o);
			if(index >= 0) {
				return osobe.get(index);
			} else return null;
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void changeData(Osoba osoba, ArrayList<Osoba> data) {
		try {
			int index = data.indexOf(osoba);
			data.remove(index);
			data.add(osoba);
			Kryo kryo = new Kryo();
	        kryo.register(Osoba.class);
	        Output out = new Output(new FileOutputStream(new File(PATH)));   
	        kryo.writeObject(out, data); 
	        out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void populateData() {
		 ArrayList<Osoba> os = new ArrayList<>();
		    try {
		        Kryo kryo = new Kryo();
		        kryo.register(Osoba.class);

		        Output out = new Output(new FileOutputStream(new File(PATH)));
		        for (int i = 0; i < 10; i++) {
		            Osoba o = new Osoba("11111111111" + i, "Ime" + 1, "Prezime" + i);
		            os.add(o);
		        }
		        
		        kryo.writeObject(out, os);  // Write the serialized object to the output stream
		 
		        out.close();
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		
	}
	
	public static ArrayList<Osoba> readData() {
		ArrayList<Osoba> o = new ArrayList<>();
	    try {
	        Kryo kryo = new Kryo();
	        kryo.register(Osoba.class);

	        Input in = new Input(new FileInputStream(new File(PATH)));
	        o = kryo.readObjectOrNull(in, ArrayList.class);
	        in.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return o;
	}
	
	public static void main(String[] args) {
		//populateData();
		/*ArrayList<Osoba> lista = readData();
		for(Osoba o : lista) {
			System.out.println(o);
		}*/
		/*addPerson(new Osoba("111111111125", "Marko", "Markovic"));
		ArrayList<Osoba> lista = readData();
		for(Osoba o : lista) {
			System.out.println(o);
		}*/
		Osoba o = getPerson("111111111125");
		System.out.println(o);
	}
	//writeObject
	//readObjectOrNull
	
}
