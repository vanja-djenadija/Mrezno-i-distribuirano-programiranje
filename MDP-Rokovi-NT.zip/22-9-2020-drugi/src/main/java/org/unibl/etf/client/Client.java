package org.unibl.etf.client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

import org.unibl.etf.model.Osoba;
import org.unibl.etf.server.Server;

public class Client {

	public static final String HOST="localhost";
	public static void main(String[] args) {
		try {
			 InetAddress address = InetAddress.getByName(HOST);
			 Socket socket = new Socket(address, Server.PORT);
			 ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
			 ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
			 /*Osoba o = new Osoba("111111151111151", "Osoba12", "Prezime111");
			 out.writeObject("ADD");
			 out.writeObject(o);
			 String response = (String)in.readObject();
			 System.out.println(response);*/
			 out.writeObject("SHOW");
			 out.writeObject("111111151111151");
			 String response = (String)in.readObject();
			 System.out.println(response);
			 out.writeObject("END");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
