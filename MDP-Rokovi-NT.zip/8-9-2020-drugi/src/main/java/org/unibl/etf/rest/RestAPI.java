package org.unibl.etf.rest;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/rest")
public class RestAPI {

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addNumbers(ArrayList<Integer> numbers) {
		return Response.status(200).entity(RestService.addNumbers(numbers)).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response returnDate() {
		return Response.status(200).entity(RestService.getDate()).build();
	}
	
}
