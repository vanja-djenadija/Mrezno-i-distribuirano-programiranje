package org.unibl.etf.rest;

import java.util.ArrayList;
import java.util.Date;

import org.unibl.etf.model.Model;

public class RestService {

	public static Model addNumbers(ArrayList<Integer> nums) {
		Integer result = 0;
		for(Integer num : nums) {
			result += num;
		}
		return new Model(String.valueOf(result), "sum");
	}
	
	public static Model getDate() {
		Date d = new Date();
		return new Model(new Date().toString(), "date");
	}
	
	//TEST - radi
	public static void main(String[] args) {
		ArrayList<Integer> nums = new ArrayList<>();
		nums.add(1);nums.add(5);nums.add(3);
		//System.out.println(addNumbers(nums));
		//System.out.println(getDate());
	}
	
}
