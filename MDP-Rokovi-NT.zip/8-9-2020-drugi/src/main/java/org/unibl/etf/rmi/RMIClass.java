package org.unibl.etf.rmi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.model.Model;

import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Input;
import com.esotericsoftware.kryo.io.Output;
import com.google.gson.Gson;

public class RMIClass implements RMIInterface {

	private static String URI = "http://localhost:8080/8-9-2020-drugi/api/rest/";
	
	@Override
	public int addResult(int a, int b, int c) throws RemoteException {
		try {
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(URI);
			ArrayList<Integer> arrList = new ArrayList<>();
			arrList.add(a); arrList.add(b); arrList.add(c);
			Response response = target.request(MediaType.APPLICATION_JSON).post(Entity.entity(arrList, MediaType.APPLICATION_JSON));
			if(response.getStatus() == 200) {
				String json = response.readEntity(String.class);
				Gson gson = new Gson();
				Model m = gson.fromJson(json, Model.class);
				return Integer.valueOf(m.getResult());
			} else {
				return -1;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	@Override
	public String getDate() throws RemoteException {
		try {
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(URI);
			Response response = target.request(MediaType.APPLICATION_JSON).get();
			if(response.getStatus() == 200) {
				String json = response.readEntity(String.class);
				Gson gson = new Gson();
				Model m = gson.fromJson(json, Model.class);
				return m.getResult();
			} else {
				return null;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean saveText(String filename, String text) throws RemoteException {
		try {
			Kryo kryo = new Kryo();
			kryo.register(String.class);
			Output out = new Output(new FileOutputStream(new File(filename)));
			kryo.writeClassAndObject(out, text);
			out.close();
			return true;  
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public String readFile(String filename) throws RemoteException {
		String result = "";
		try {
			Kryo kryo = new Kryo();
			kryo.register(String.class);
			Input in = new Input(new FileInputStream(new File(filename)));
			result = (String) kryo.readClassAndObject(in);
			in.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	} 
	
	public static void main(String[] args) {
		
		try {
			System.setProperty("java.security.policy", "."+File.separator+"policy.txt");
			if(System.getSecurityManager() == null) {
				System.setSecurityManager(new SecurityManager());
			}
			
			RMIClass rmi = new RMIClass();
			RMIInterface stub = (RMIInterface)UnicastRemoteObject.exportObject(rmi, 0);
			Registry registry = LocateRegistry.createRegistry(1099);
			registry.bind("Stub", stub);
			
			//rmi.saveText("a.txt", "Tekst!"); 
			/*String sb = rmi.readFile("a.txt");
			System.out.println(sb) ;*/
			//rmi.getDate();
			//System.out.println(rmi.getDate());
			//System.out.println(rmi.addResult(5, 2, 1));
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
