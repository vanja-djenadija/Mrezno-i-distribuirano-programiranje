package org.unibl.etf.server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Properties;

import org.unibl.etf.model.Phone;

public class ServerThread extends Thread {

	private Socket socket;
	private ObjectOutputStream out;
	private ObjectInputStream in;
	
	public ServerThread(Socket s) {
		try {
			 socket = s;
			 out = new ObjectOutputStream(s.getOutputStream());
			 in = new ObjectInputStream(s.getInputStream());
			 start();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream(new File("./config.properties")));
			String state = properties.getProperty("STANJE");
			String separator = properties.getProperty("SEPARATOR");
			String internet = properties.getProperty("INTERNET");
			String add = properties.getProperty("DOPUNI");
			String err = properties.getProperty("ERROR");
			String notFound = properties.getProperty("NOT_FOUND");
			String request = "";
			File f = new File("."+File.separator+"telefoni.csv");
			while(!"END".equals(request)) {
				request = (String)in.readObject();
				System.out.println("REQUEST = " + request);
				if(request.startsWith(state)) {	
					BufferedReader br = new BufferedReader(new FileReader(f));
					String[] split = request.split(separator);
					String number = split[1];
					String readLine="";
					boolean found = false;
					while((readLine=br.readLine()) != null) {
						String[] splitLine = readLine.split(",");
						if(splitLine[0] != null && splitLine[0].equals(number)) {
							found = true;
							out.writeObject(splitLine[2]);
						}
					}
					if(!found) {
						out.writeObject(notFound);
					}
					br.close();
				} else if(request.startsWith(internet)) {
					BufferedReader br = new BufferedReader(new FileReader(f));
					String[] split = request.split(separator);
					String number = split[1];
					System.out.println(number);
					String readLine="";
					boolean found = false;
					while((readLine=br.readLine()) != null) {
						String[] splitLine = readLine.split(",");
						if(splitLine[0] != null && splitLine[0].equals(number)) {
							found = true;
							out.writeObject(splitLine[3]);
						}
					}
					if(!found) {
						out.writeObject(notFound);
					}
					br.close();
				} else if(request.startsWith(add)) {
					BufferedReader br = new BufferedReader(new FileReader(f));
					String[] split = request.split(separator);
					String number = split[1];
					String number2 = split[2];
					System.out.println(number);System.out.println(number2);
					String readLine="";
					boolean found = false; boolean found2 = false;
					ArrayList<Phone> phones = new ArrayList<>();
					Phone p1 = new Phone(), p2 = new Phone();
					double value=0.0;
					while((readLine=br.readLine()) != null) {
						String[] splitLine = readLine.split(",");
						phones.add(new Phone(splitLine[0], splitLine[1], Double.valueOf(splitLine[2]), splitLine[3]));
						if(splitLine[0] != null && splitLine[0].equals(number)) {
							if("pripejd".equals(splitLine[1])) {
								p1.setInternet(splitLine[3]);
								p1.setPhoneNum(splitLine[0]);
								p1.setType(splitLine[1]);
								p1.setValue(0);
								value = Double.valueOf(splitLine[2]);
								found = true;
							} else {
								p2.setInternet(splitLine[3]);
								p2.setPhoneNum(splitLine[0]);
								p2.setType(splitLine[1]);
								p2.setValue(Double.valueOf(splitLine[2]));
								found2 = true;
							}
							
						}
						if(splitLine[0] != null && splitLine[0].equals(number2)) {
							if("pripejd".equals(splitLine[1])) {
								p1.setInternet(splitLine[3]);
								p1.setPhoneNum(splitLine[0]);
								p1.setType(splitLine[1]);
								p1.setValue(Double.valueOf(0));
								value = Double.valueOf(splitLine[2]);
								found = true;
							} else {
								p2.setInternet(splitLine[3]);
								p2.setPhoneNum(splitLine[0]);
								p2.setType(splitLine[1]);
								p2.setValue(Double.valueOf(splitLine[2]));
								found2 = true;
							}
							
						}
					}
					if(!found || !found2) {
						out.writeObject(notFound);
					} else {
						p2.setValue(p2.getValue()+value);
						out.writeObject(p1);
						out.writeObject(p2);
						FileWriter fw = new FileWriter(new File("./telefoni.csv"));
						for(Phone p : phones) {
							if(p != p1 && p != p2) {
								fw.append(String.join(",", p.getPhoneNum(), p.getType(), String.valueOf(p.getValue()), p.getInternet()));
							}
						}
						fw.append(String.join(",", p1.getPhoneNum(), p1.getType(), String.valueOf(p1.getValue()), p1.getInternet()));
						fw.append(String.join(",", p2.getPhoneNum(), p2.getType(), String.valueOf(p2.getValue()), p2.getInternet()));
						fw.close();
					}
					br.close();
				} else {
					out.writeObject(err);
				}
			}
			socket.close();
			in.close();
			out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
}
