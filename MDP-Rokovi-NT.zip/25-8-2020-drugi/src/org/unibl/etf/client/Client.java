package org.unibl.etf.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Properties;
import java.util.Scanner;

import org.unibl.etf.model.Phone;
import org.unibl.etf.server.Server;

public class Client {

	public static void main(String[] args) {
		
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream(new File("./config.properties")));
			String state = properties.getProperty("STANJE");
			String separator = properties.getProperty("SEPARATOR");
			String internet = properties.getProperty("INTERNET");
			String add = properties.getProperty("DOPUNI");
			String err = properties.getProperty("ERROR");
			String notFound = properties.getProperty("NOT_FOUND");
			System.out.println("HERE");
			Socket s = new Socket(InetAddress.getByName("localhost"), Server.PORT);
			ObjectInputStream in = new ObjectInputStream(s.getInputStream());
			ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
			Scanner scan = new Scanner(System.in);
			System.out.println("HERE");
			String input="", response="";
			System.out.println("OPTION (1 for state, 2 for internet, 3 for more money on account) ");
			while(!"END".equals(input)) {	
				input = scan.nextLine();
				String extraInput="", extraInput2="";
				if("1".equals(input)) {
					System.out.println("Phone num: ");
					extraInput = scan.nextLine();
					out.writeObject(state + separator + extraInput);
					response = (String)in.readObject();
					System.out.println("Response = " + response);
				} else if("2".equals(input)) {
					System.out.println("Phone num: ");
					extraInput = scan.nextLine();
					out.writeObject(internet + separator + extraInput);
					response = (String)in.readObject();
					System.out.println("Response = " + response);
				} else if("3".equals(input)) {
					System.out.println("Phone num 1: ");
					extraInput = scan.nextLine();
					System.out.println("Phone num 2: ");
					extraInput2 = scan.nextLine();
					out.writeObject(add + separator + extraInput + separator + extraInput2);
					//response = (String)in.readObject();
					Phone p1 = (Phone)in.readObject();
					Phone p2 = (Phone)in.readObject();
					System.out.println("Response = " + p1);
					System.out.println("Response = " + p2);
				} else if("END".equals(input)) {
					out.writeObject("END");
				} else {
					System.out.println("Error, try again!");
				}
				
				
			}
			

			scan.close();
			in.close();
			out.close();
			s.close();
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

}
