package org.unibl.etf.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("./test.csv")));
			String line="", content="";
			while((line=br.readLine()) != null) {
				content += line;
				content += "-";
			}
			System.out.println(content);
			br.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
