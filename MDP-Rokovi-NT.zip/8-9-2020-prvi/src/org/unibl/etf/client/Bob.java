package org.unibl.etf.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

import org.unibl.etf.messages.ProtocolMessage;
import org.unibl.etf.server.Server;

public class Bob {

	
	public static void main(String[] args) {
		try {
			Socket s = new Socket(InetAddress.getByName("localhost"), Server.PORT);
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
			Scanner scan = new Scanner(System.in);
			String response = "";
			out.println("Bob");
			response = in.readLine();
			
			if(ProtocolMessage.THERE_IS_A_FILE.equals(response)) {
				
				response = in.readLine();
				String[] split = response.split("/");
				System.out.println("FILE CONTENT: ");
				
				for(String sp : split) {
					System.out.println(sp);
				}
				String question = in.readLine();
				System.out.println("QUESTION = " + question);
				System.out.println("Enter your answer: ");
				String answer = scan.nextLine();
				out.println(answer);
				System.out.println("Answer read = " + in.readLine());
			} else {
				String response2 = in.readLine();
				System.out.println("Response no file " + response2);
			}
			
			scan.close();
			out.close();
			in.close();
			s.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
