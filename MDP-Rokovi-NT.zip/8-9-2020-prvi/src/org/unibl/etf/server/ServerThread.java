package org.unibl.etf.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import org.unibl.etf.messages.ProtocolMessage;

public class ServerThread extends Thread {

	private PrintWriter out;
	private BufferedReader in;
	private Socket socket;
	
	public ServerThread(Socket s) {
		try {
			
			socket = s;
			out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
			in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			start();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		
		try {
			String input="";
			input = in.readLine();
			if("Alice".equals(input)) {
				File f = new File("bob.txt");
				if(!f.exists()) {
					out.println(ProtocolMessage.NO_FILE);
					input = in.readLine();
					if(ProtocolMessage.UPLOAD.equals(input)) {
						input = in.readLine();
						System.out.println(input);
						String[] split = input.split("/");
						split[2]+="?";
						PrintWriter pw = new PrintWriter(new File("./alisa.txt"));
						for(String s : split) {
							pw.println(s);
						}
						pw.close();
						input = in.readLine(); //citanje odgovora
						PrintWriter pw2 = new PrintWriter(new File("./odgovor.txt"));
						pw2.println(input);
						pw2.close();
					} else {
						out.println(ProtocolMessage.ERROR);
					}
				} else {
					System.out.println("IN ELSE!");
					out.println(ProtocolMessage.THERE_IS_A_FILE);
					input = in.readLine();
					if(ProtocolMessage.DOWNLOAD.equals(input)) {
						File fi = new File("./bob.txt");
						BufferedReader br = new BufferedReader(new FileReader(fi));
						ArrayList<String> strings = new ArrayList<>();
						String content="", line=""; int counter = 0; String question="";
						while((line=br.readLine()) != null) {
							strings.add(line);
							System.out.println("Line = " + line);
							content += line;
							String bl = line;
							content += "-";
							if(counter == 2) question = bl;
							counter++;
						}
						br.close();
						System.out.println("QUESTION = " + question);
						System.out.println("CONTENT = " + content);
						out.println(content);
						System.out.println(content+fi.length());
						out.println(question+fi.length());
						
						
						
						BufferedReader br2 = new BufferedReader(new FileReader(new File("./odgovor.txt")));
						String readAnswer="", answerLine="";
						while((answerLine=br2.readLine()) != null ) {
							readAnswer += answerLine;
						}
						br2.close();
						
						if(readAnswer.equals(question)) {
							System.out.println("YES");
							out.println("YES");
						} else {
							System.out.println("NO");
							out.println("NO");
						}
					} else {
						out.println(ProtocolMessage.ERROR);
					}
				}
			} else if("Bob".equals(input)) {
				File f = new File("alisa.txt");
				if(f.exists()) {
					out.println(ProtocolMessage.THERE_IS_A_FILE);
					BufferedReader br = new BufferedReader(new FileReader(new File("./alisa.txt")));
					ArrayList<String> strings = new ArrayList<>();
					String content="", line=""; int counter = 0; String question="";
					while((line=br.readLine()) != null) {
						strings.add(line);
						content += line;
						content += "/";
						if(counter == 2) question = line;
						counter++;
					}
					
					out.println(content);
					out.println(question);
					br.close();
					
					String bobResponse = in.readLine();
					
					PrintWriter pw = new PrintWriter(new File("./bob.txt")); //fajl koji bob salje alisi
					
					strings.remove(2);
					strings.add(2, bobResponse);
					for(String s : strings) {
						pw.println(s);
					}
					
					pw.close();
					
					BufferedReader br2 = new BufferedReader(new FileReader(new File("./odgovor.txt")));
					String readAnswer="", answerLine="";
					while((answerLine=br2.readLine()) != null ) {
						readAnswer += answerLine;
					}
					br2.close();
					File f22 = new File("./alisa.txt");
					out.println(readAnswer + f22.length());
					
				} else {
					out.println(ProtocolMessage.NO_FILE);
					
				}
			} else {
				out.println(ProtocolMessage.ERROR);
			}
			socket.close();
			in.close();
			out.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
}
