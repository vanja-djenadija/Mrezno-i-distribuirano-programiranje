package org.unibl.etf.messages;

public class ProtocolMessage {

	public static String THERE_IS_A_FILE="THERE_IS_A_FILE_FOR_YOU";
	public static String NO_FILE="THERE_IS_NO_FILE";
	public static String DOWNLOAD="DOWNLOAD";
	public static String UPLOAD="UPLOAD";
	public static String ERROR="ERROR";
	public static String END="END";
}
