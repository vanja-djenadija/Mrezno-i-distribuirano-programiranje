package org.unibl.etf.mdp.model;

import java.io.Serializable;

public class Poruka implements Serializable {

	private String naslov;
	private String sadrzaj;
	private int idPrimaoca;
	private int idPosiljaoca;
	public Poruka(String naslov, String sadrzaj, int idPrimaoca, int idPosiljaoca) {
		super();
		this.naslov = naslov;
		this.sadrzaj = sadrzaj;
		this.idPrimaoca = idPrimaoca;
		this.idPosiljaoca = idPosiljaoca;
	}
	public Poruka() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getNaslov() {
		return naslov;
	}
	public void setNaslov(String naslov) {
		this.naslov = naslov;
	}
	public String getSadrzaj() {
		return sadrzaj;
	}
	public void setSadrzaj(String sadrzaj) {
		this.sadrzaj = sadrzaj;
	}
	public int getIdPrimaoca() {
		return idPrimaoca;
	}
	public void setIdPrimaoca(int idPrimaoca) {
		this.idPrimaoca = idPrimaoca;
	}
	public int getIdPosiljaoca() {
		return idPosiljaoca;
	}
	public void setIdPosiljaoca(int idPosiljaoca) {
		this.idPosiljaoca = idPosiljaoca;
	}
	@Override
	public String toString() {
		return "Poruka [naslov=" + naslov + ", sadrzaj=" + sadrzaj + ", idPrimaoca=" + idPrimaoca + ", idPosiljaoca="
				+ idPosiljaoca + "]";
	}
	
	
	
}
