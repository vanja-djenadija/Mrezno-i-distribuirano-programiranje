package org.unibl.etf.mdp.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

public class PorukaServis {

	private static ArrayList<Poruka> poruke = new ArrayList<>();
	private static final String PUTANJA_PORUKE="."+File.separator+"Poruke"+File.separator;
	private static final String PUTANJA_KORISNICI="."+File.separator+"Korisnici"+File.separator;
	private static final String PUTANJA_TROSKOVI="."+File.separator+"Troskovi"+File.separator;
	public static boolean posaljiPoruku(Poruka p) {
		try {
			File f = new File(PUTANJA_PORUKE+new Date().getTime());
			if(!f.exists()) {
				f.createNewFile();
			}
			PrintWriter pw = new PrintWriter(f);
			Gson gson = new Gson();
			pw.println(gson.toJson(p));
			pw.close();
			Troskovi t = new Troskovi(p.getIdPosiljaoca(), "pregled", 0.15);
			File f1 = new File(PUTANJA_TROSKOVI);
			PrintWriter pw2 = new PrintWriter(f1);
			pw2.println(gson.toJson(t));
			pw2.close();
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public static ArrayList<Poruka> pregledajPoruke(int id) {
		ArrayList<Poruka> rezultat = new ArrayList<>();
		try {		
			Gson gson = new Gson();
			File f = new File(PUTANJA_PORUKE);
			File[] fajlovi = f.listFiles();
			for(File fajl : fajlovi) {
				String linija="", json="";
				BufferedReader br = new BufferedReader(new FileReader(fajl));
				while((linija = br.readLine()) != null) {
					json += linija;
				}
				Poruka p = gson.fromJson(json, Poruka.class);
				if(p.getIdPrimaoca() == id) {
					rezultat.add(p);
				}
				br.close();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return rezultat;
	}
	
	public static ArrayList<Korisnik> pregledajKorisnike(int id) {
		ArrayList<Korisnik> rezultat = new ArrayList<>();
		Gson gson = new Gson();
		try {		
			
			File f = new File(PUTANJA_KORISNICI);
			File[] fajlovi = f.listFiles();
			for(File fajl : fajlovi) {
				String linija="", json="";
				BufferedReader br = new BufferedReader(new FileReader(fajl));
				while((linija = br.readLine()) != null) {
					json += linija;
				}
				Korisnik p = gson.fromJson(json, Korisnik.class);
				rezultat.add(p);
				br.close();
				
			}
			Troskovi t = new Troskovi(id, "pregled", 0.07);
			File f1 = new File(PUTANJA_TROSKOVI);
			PrintWriter pw2 = new PrintWriter(f1);
			pw2.println(gson.toJson(t));
			pw2.close();
		} catch(Exception e) {
			e.printStackTrace();
		}		
		return rezultat;
	}
	
	public static String obrisiPoruke(int id, int brojPoruka) {
		int ukupno = 0;
		try {		
			ArrayList<File> fajloviZaBrisanje = new ArrayList<>();
			int brojac=0;
			Gson gson = new Gson();
			File f = new File(PUTANJA_PORUKE);
			File[] fajlovi = f.listFiles();
			for(File fajl : fajlovi) {
				String linija="", json="";
				BufferedReader br = new BufferedReader(new FileReader(fajl));
				while((linija = br.readLine()) != null) {
					json += linija;
				}
				Poruka p = gson.fromJson(json, Poruka.class);
				if(p.getIdPosiljaoca() == id && brojac < brojPoruka) {
					ukupno++;
					brojac++;
					fajloviZaBrisanje.add(fajl);
				} else ukupno++;
				br.close(); 
			}
			//if(brojac < brojPoruka) return false;
			for(File fajl : fajloviZaBrisanje) fajl.delete();
		} catch(Exception e) {
			
			e.printStackTrace();
			return "Greska!";
		}
		if(brojPoruka > ukupno) return "Greska, ostalo " + (ukupno-brojPoruka) + " poruka!";
		else return "Ostalo 0 poruka!";
		
	}
	
	
	private static void napuniPodatke() {
		try {
			Gson gson = new Gson();
			for(int i=0; i<5; i++) {
				Korisnik k = new Korisnik(i+1, "Ime"+i, "Prezime"+i);
				File f = new File(PUTANJA_KORISNICI+(i+1));
				PrintWriter pw = new PrintWriter(f);
				pw.println(gson.toJson(k));
				pw.close();
			}
			for(int i=0; i<5; i++) {
				String tip = "slanje";
				if(i%2==0) tip = "pregled";
				Troskovi t = new Troskovi(i+1, tip, i*4+2.50);
				File f = new File(PUTANJA_TROSKOVI+(i+1));
				PrintWriter pw = new PrintWriter(f);
				pw.println(gson.toJson(t));
				pw.close();
			}
			for(int i=1; i<5; i++) {
				Poruka p = new Poruka("Naslov"+i, "Sadrzaj"+i, i, i+1);
				File f = new File(PUTANJA_PORUKE+(i+1));
				PrintWriter pw = new PrintWriter(f);
				pw.println(gson.toJson(p));
				pw.close();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static double zbirniTroskovi(int id) {
		double ukupno = 0.0;
		try {		
			Gson gson = new Gson();
			File f = new File(PUTANJA_TROSKOVI);
			File[] fajlovi = f.listFiles();
			for(File fajl : fajlovi) {
				String linija="", json="";
				BufferedReader br = new BufferedReader(new FileReader(fajl));
				while((linija = br.readLine()) != null) {
					json += linija;
				}
				Troskovi p = gson.fromJson(json, Troskovi.class);
				br.close();
				if(p.getId() == id) {
					ukupno += p.getCijena();
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return ukupno;
	}
	
	public static double troskoviPoParametru(int id, String parametar) {
		double ukupno = 0.0;
		try {		
			Gson gson = new Gson();
			File f = new File(PUTANJA_TROSKOVI);
			File[] fajlovi = f.listFiles();
			for(File fajl : fajlovi) {
				String linija="", json="";
				BufferedReader br = new BufferedReader(new FileReader(fajl));
				while((linija = br.readLine()) != null) {
					json += linija;
				}
				Troskovi p = gson.fromJson(json, Troskovi.class);
				br.close();
				if(p.getId() == id && p.getTipTroska().equals(parametar)) {
					ukupno += p.getCijena();
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return ukupno;
	}
	
	//Main radi, REST ne
	public static void main(String[] args) {
		//napuniPodatke(); RADI
		//Poruka p = new Poruka("Porukaaaaa", "Sadrzajjjjj", 1, 3);
		//posaljiPoruku(p); RADI
		/*ArrayList<Poruka> poruke = pregledajPoruke(3);
		for(Poruka p : poruke) {
			System.out.println(p);
		}*/
		/*boolean status = obrisiPoruke(3, 1);
		System.out.println(status);*/
		/*double troskovi = troskoviPoParametru(1, "pregled"); //RADI
		System.out.println(troskovi);*/
	}
	
}
