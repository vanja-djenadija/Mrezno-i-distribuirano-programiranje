package org.unibl.etf.mdp.model;

public class Troskovi {
	
	private int id;
	private String tipTroska; //slanje ili pregled
	private double cijena;
	public Troskovi(int id, String tipTroska, double cijena) {
		super();
		this.id = id;
		this.tipTroska = tipTroska;
		this.cijena = cijena;
	}
	public Troskovi() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTipTroska() {
		return tipTroska;
	}
	public void setTipTroska(String tipTroska) {
		this.tipTroska = tipTroska;
	}
	public double getCijena() {
		return cijena;
	}
	public void setCijena(double cijena) {
		this.cijena = cijena;
	}
	
	
	
	
}
