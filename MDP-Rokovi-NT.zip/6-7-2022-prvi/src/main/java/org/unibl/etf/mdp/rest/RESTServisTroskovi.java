package org.unibl.etf.mdp.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.mdp.model.PorukaServis;

@Path("/troskovi")
public class RESTServisTroskovi {

	@GET
	@Path("/{id}/{parametar}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response procitajPoruke(@PathParam("id")int id, @PathParam("parametar")String parametar) {
		System.out.println("IN");
		return Response.status(200).entity(PorukaServis.troskoviPoParametru(id, parametar)).build();
	}
	
}