package org.unibl.etf.mdp.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.List;

import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;
import org.unibl.etf.mdp.model.Korisnik;
import org.unibl.etf.mdp.model.Poruka;
import org.unibl.etf.mdp.model.PorukaServis;

/*@GET
	@Path("/{id}/{parametar}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response procitajPoruke(@PathParam("id")int id, @PathParam("parametar")String parametar) {
		return Response.status(200).entity(PorukaServis.troskoviPoParametru(id, parametar)).build();
	}*/
public class Klijent {

	private static String URI1="http://localhost:8080/6-7-2022-prvi/api/putanja1/";
	private static String URI2="http://localhost:8080/6-7-2022-prvi/api/troskovi/";
	
	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public static JSONObject readOne(String id) throws IOException, JSONException {
		InputStream is = new URL(URI1 + id).openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject json = new JSONObject(jsonText);
			return json;
		} finally {
			is.close();
		}
	}
	
	public static void main(String[] args) {
		try {
			Poruka p = new Poruka("n","s", 2, 1);
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(URI1);
			System.out.println(URI1);
			Response response = target.request(MediaType.APPLICATION_JSON).post(Entity.entity(p, MediaType.APPLICATION_JSON));
			System.out.println(response.getStatus());					
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
