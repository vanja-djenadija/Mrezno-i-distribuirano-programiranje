package org.unibl.etf.client;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class Client {

	private static String URI = "http://localhost:8080/16-6-2020-prvi/api/vozilo/";
	private static String URI2 = "http://localhost:8080/16-6-2020-prvi/api/voziloid/";
	
	public static void main(String[] args) {
		
		try {
			
			javax.ws.rs.client.Client client = ClientBuilder.newClient();
			WebTarget target = client.target(URI+1);
			Response response = target.request(MediaType.APPLICATION_JSON).get();
			/*if(response.getStatus() == 200) {
				System.out.println(200); //radi, samo treba iscitati (chatgpt)
			}
			
			target = client.target(URI+4+"/Pr6");
			response = target.request(MediaType.APPLICATION_JSON).get();
			if(response.getStatus() == 200) {
				System.out.println(200); 
				String s = response.readEntity(String.class);
				System.out.println(s);
			}
			target = client.target(URI+3+"/"+6);
			response = target.request(MediaType.APPLICATION_JSON).delete();
			if(response.getStatus() == 200) {
				System.out.println(200); 
				String s = response.readEntity(String.class);
				System.out.println(s);
			}*/
			target = client.target(URI2+2+"/"+10);
			response = target.request(MediaType.APPLICATION_JSON).get();
			if(response.getStatus() == 200) {
				System.out.println(200); 
				String s = response.readEntity(String.class);
				System.out.println(s);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

}
