package org.unibl.etf.model;

import java.util.Objects;

public class Vozilo {

	private int id;
	private int godiste;
	private String proizvodjac;
	private String model;
	private String opis;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getGodiste() {
		return godiste;
	}
	public void setGodiste(int godiste) {
		this.godiste = godiste;
	}
	public String getProizvodjac() {
		return proizvodjac;
	}
	public void setProizvodjac(String proizvodjac) {
		this.proizvodjac = proizvodjac;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getOpis() {
		return opis;
	}
	public void setOpis(String opis) {
		this.opis = opis;
	}
	public Vozilo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vozilo(int id, int godiste, String proizvodjac, String model, String opis) {
		super();
		this.id = id;
		this.godiste = godiste;
		this.proizvodjac = proizvodjac;
		this.model = model;
		this.opis = opis;
	}
	@Override
	public String toString() {
		return "Vozilo [id=" + id + ", godiste=" + godiste + ", proizvodjac=" + proizvodjac + ", model=" + model
				+ ", opis=" + opis + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vozilo other = (Vozilo) obj;
		return id == other.id;
	}
	
	public Vozilo(int id) {
		this.id = id;
	}
	
}
