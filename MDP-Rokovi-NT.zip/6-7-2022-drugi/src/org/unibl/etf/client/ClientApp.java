package org.unibl.etf.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.Socket;

import org.unibl.etf.server.MulticastClass;
import org.unibl.etf.server.Server;

public class ClientApp {

	public static final String HOST = "localhost";
	
	
	public static void main(String[] args) {
		try {
			
			Socket s = new Socket(InetAddress.getByName(HOST), Server.SERVER_PORT);
			PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			String response = "";
			
			out.println("GET_STATUS");
			response = in.readLine();
			System.out.println(response);
			
			out.println("ADD");
			response = in.readLine();
			System.out.println(response);
			out.println("NUMBER#5");
			response = in.readLine();
			System.out.println(response);
			out.println("NUMBER#15");
			response = in.readLine();
			System.out.println(response);
			out.println("NUMBER#20");
			response = in.readLine();
			System.out.println(response);
			out.println("NUMBER#7");
			response = in.readLine();
			System.out.println(response);
			out.println("NUMBER#1");
			response = in.readLine();
			System.out.println(response);
			out.println("TOTAL");
			response = in.readLine();
			System.out.println(response);
			out.println("END");
			
			InetAddress addr2 = InetAddress.getByName(MulticastClass.MULTICAST_ADDRESS);
			MulticastSocket msocket = new MulticastSocket(20000);
			byte[] buffer = new byte[256];
			msocket.joinGroup(addr2);
			//CISTO RADI TESTIRANJA
			while(true) {
				DatagramPacket paket = new DatagramPacket(buffer, buffer.length);
				msocket.receive(paket);
				String str = new String(buffer);
				System.out.println(str);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
