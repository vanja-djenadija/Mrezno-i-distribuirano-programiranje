package org.unibl.etf.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

import org.unibl.etf.model.Blog;
import org.unibl.etf.model.Korisnici;
import org.unibl.etf.model.Korisnik;
import org.unibl.etf.model.Messages;

import com.google.gson.Gson;

public class ServerThread extends Thread {

	private ObjectInputStream in;
	private ObjectOutputStream out;
	private Socket socket;
	private Gson gson = new Gson();
	private Korisnik k;
	public ServerThread(Socket s) {
		try {
			this.socket = s;
			out = new ObjectOutputStream(s.getOutputStream());
			in = new ObjectInputStream(s.getInputStream());
			k = new Korisnik(s.getRemoteSocketAddress().toString(), new Date());
			Korisnici.korisnici.add(k);
			Server.NUM_CONNS++;
		} catch(IOException e) {
			e.printStackTrace();
		}
		start();
	}
	
	
	@Override
	public void run() {
		try {
			System.out.println("STARTED!!!");
			String ulaz="";
			while(!Messages.KRAJ.equals(ulaz)) {
				ulaz = (String)in.readObject();
				if(Messages.KREIRAJ_BLOG.equals(ulaz)) {
					System.out.println("In blog create!!!");
					Blog b = (Blog)in.readObject();
					PrintWriter pw = new PrintWriter(Messages.BLOG_PUTANJA + new File("a.txt"));
					pw.println(gson.toJson(b));
					pw.close();
				} else if(Messages.PRETRAZI.equals(ulaz)) {
					System.out.println("IN PRETRAZI");
					String s = (String)in.readObject();
					File f = new File(Messages.BLOG_PUTANJA);
					File[] fajlovi = f.listFiles();
					String blogovi = "";
					ArrayList<Blog> blogs = new ArrayList<>();
					for(File fajl : fajlovi) {
						String input="", json="";
						BufferedReader read = new BufferedReader(new FileReader(fajl));
						while((input=read.readLine()) != null) {
							json+=input;
						}
						Blog b = gson.fromJson(json, Blog.class);
						if(b.getTekst().contains(s)) {
							blogs.add(b);
						}
						//out.writeObject(b);
					}
					System.out.println("BLOGOVI");
					for(Blog b : blogs) {
						System.out.println(b);
					}
					out.writeObject(blogs);
					//out.flush();
				} else if(Messages.SVI_BLOGOVI.equals(ulaz)) {
					File f = new File(Messages.BLOG_PUTANJA);
					File[] fajlovi = f.listFiles();
					String blogovi = "";
					ArrayList<Blog> blogs = new ArrayList<>();
					for(File fajl : fajlovi) {
						String input="", json="";
						BufferedReader read = new BufferedReader(new FileReader(fajl));
						while((input=read.readLine()) != null) {
							json+=input;
						}
						Blog b = gson.fromJson(json, Blog.class);
						blogs.add(b);
					}
					out.writeObject(blogs);
					//out.flush();
				} else if(Messages.KRAJ.equals(ulaz)) {
					
				} else {
					//pogresna opcija
					out.writeObject("GRESKA");
					//out.flush();
				}
				
			}
			
			
			socket.close();
			in.close();
			out.close();
			
			Thread.sleep(30000);
			
			Korisnici.korisnici.remove(k);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		//while(!"")
		
		
		
	}
	
}
