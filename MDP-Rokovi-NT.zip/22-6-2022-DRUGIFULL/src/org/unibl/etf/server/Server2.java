package org.unibl.etf.server;

import java.net.ServerSocket;
import java.net.Socket;

public class Server2 {

	public static final int PORT = 9001;
	private static int NUM_CONNS;
	
	public static int getNumConns() {
		return NUM_CONNS;
	}
	
	
	public static void main(String[] args) {
		try {
			ServerSocket ss = new ServerSocket(PORT);
			System.out.println("Server pokrenut!");
			while(true) {
				Socket s = ss.accept();
				new ServerThread2(s);
				NUM_CONNS++;	
				System.out.println("Klijent prihvacen!");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
}
