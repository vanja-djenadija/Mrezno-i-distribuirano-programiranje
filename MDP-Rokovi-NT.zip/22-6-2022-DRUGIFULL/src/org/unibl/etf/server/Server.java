package org.unibl.etf.server;

import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static final int PORT = 9004;
	public static Integer NUM_CONNS=0;
	
	/*public static int getNumConns() {
		return NUM_CONNS;
	}*/
	
	
	public static void main(String[] args) {
		try {
			ServerSocket ss = new ServerSocket(PORT);
			System.out.println("Server pokrenut!");
			while(true) {
				Socket s = ss.accept();
				System.out.println("Klijent prihvacen! " + NUM_CONNS);
				new ServerThread(s);		
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
