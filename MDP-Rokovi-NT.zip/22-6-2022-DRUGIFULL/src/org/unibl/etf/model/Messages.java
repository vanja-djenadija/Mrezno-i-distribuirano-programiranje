package org.unibl.etf.model;

import java.io.File;

public class Messages {

	public static final String KRAJ="KRAJ";
	public static final String KREIRAJ_BLOG="KREIRAJ_BLOG";
	public static final String PRETRAZI="PRETRAZI";
	public static final String SVI_BLOGOVI="SVI_BLOGOVI";
	public static final String BLOG_PUTANJA = "."+File.separator+"Blogovi"+File.separator;
	public static final String BR_KOR="BR_KOR";
	public static final String PRIJAVLJENI="PRIJAVLJENI";
}
