package org.unibl.etf.model;

import java.util.Date;

public class ListaModel {

	private String regBroj;
	private Date datum;
	public String getRegBroj() {
		return regBroj;
	}
	public void setRegBroj(String regBroj) {
		this.regBroj = regBroj;
	}
	public Date getDatum() {
		return datum;
	}
	public void setDatum(Date datum) {
		this.datum = datum;
	}
	public ListaModel(String regBroj, Date datum) {
		super();
		this.regBroj = regBroj;
		this.datum = datum;
	}
	public ListaModel() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ListaModel [regBroj=" + regBroj + ", datum=" + datum + "]";
	}
	
	
	
}
