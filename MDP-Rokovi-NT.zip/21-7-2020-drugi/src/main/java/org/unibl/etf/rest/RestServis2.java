package org.unibl.etf.rest;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.model.Vozilo;
import org.unibl.etf.model.VoziloServis;

@Path("/vozilo2")
public class RestServis2 {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response dohvatiSpornaVozila() {
		ArrayList<Vozilo>  sva = VoziloServis.spornaVozila();
		if(sva != null) {
			return Response.status(200).entity(sva).build();
		} else {
			return Response.status(404).build();
		}
	}
	
}
