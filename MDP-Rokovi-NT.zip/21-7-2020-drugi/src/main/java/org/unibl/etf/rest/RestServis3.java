package org.unibl.etf.rest;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.unibl.etf.model.ListaModel;
import org.unibl.etf.model.Vozilo;
import org.unibl.etf.model.VoziloServis;

@Path("/vozilo3")
public class RestServis3 {

	@GET
	@Path("/{kriterijum}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response dohvatiSortirane(@PathParam("kriterijum")int kriterijum) {
		ArrayList<ListaModel>  sva = VoziloServis.dohvatiSortirane(kriterijum);
		if(sva != null) {
			return Response.status(200).entity(sva).build();
		} else {
			return Response.status(404).build();
		}
	}
	
}
