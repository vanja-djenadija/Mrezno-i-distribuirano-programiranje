package org.unibl.etf.model;

import java.util.Date;

public class Registracija {

	private Date datumRegistracije;
	private int kilometraza;
	private String komentar;
	public Registracija(Date datumRegistracije, int kilometraza, String komentar) {
		super();
		this.datumRegistracije = datumRegistracije;
		this.kilometraza = kilometraza;
		this.komentar = komentar;
	}
	public Registracija() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Date getDatumRegistracije() {
		return datumRegistracije;
	}
	public void setDatumRegistracije(Date datumRegistracije) {
		this.datumRegistracije = datumRegistracije;
	}
	public int getKilometraza() {
		return kilometraza;
	}
	public void setKilometraza(int kilometraza) {
		this.kilometraza = kilometraza;
	}
	public String getKomentar() {
		return komentar;
	}
	public void setKomentar(String komentar) {
		this.komentar = komentar;
	}
	@Override
	public String toString() {
		return "Registracija [datumRegistracije=" + datumRegistracije + ", kilometraza=" + kilometraza + ", komentar="
				+ komentar + "]";
	}
	
	
	
}
